﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using WindowsFormsApp1;

namespace QuanLyNhanSu
{
    public partial class FormLapQuyetDinh : Form
    {
        RadioButton rdoCaNhan, rdoTapThe;
        Label lblDoiTuong;
        ComboBox cboDoiTuong, cboLoaiThuong;
        TextBox txtNoiDung, txtSoTien;
        DateTimePicker dtpNgayQD;
        Button btnLuu, btnLamMoi, btnKyDuyet;
        DataGridView dgv;

        public FormLapQuyetDinh()
        {
            InitializeComponent();
            DungGiaoDien();
            LoadDoiTuong();
            LoadDanhSach();
        }

        // ---------- Giao diện (dựng bằng code) ----------
        Label Lbl(string text, int x, int y, bool bold = false, float size = 10)
        {
            var l = new Label();
            l.Text = text;
            l.AutoSize = true;
            l.Location = new Point(x, y);
            l.Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular);
            Controls.Add(l);
            return l;
        }

        void DungGiaoDien()
        {
            Text = "Lập quyết định khen thưởng";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(900, 640);
            Font = new Font("Segoe UI", 10);

            Lbl("LẬP QUYẾT ĐỊNH KHEN THƯỞNG", 20, 15, true, 16);

            Lbl("Đối tượng khen thưởng:", 20, 65);
            rdoCaNhan = new RadioButton { Text = "Cá nhân", Location = new Point(200, 62), Width = 100, Checked = true };
            rdoTapThe = new RadioButton { Text = "Tập thể phòng ban", Location = new Point(310, 62), Width = 200 };
            Controls.Add(rdoCaNhan);
            Controls.Add(rdoTapThe);

            lblDoiTuong = Lbl("Nhân viên:", 20, 108);
            cboDoiTuong = new ComboBox { Location = new Point(200, 105), Width = 400, DropDownStyle = ComboBoxStyle.DropDownList };
            Controls.Add(cboDoiTuong);

            Lbl("Loại thưởng:", 20, 148);
            cboLoaiThuong = new ComboBox { Location = new Point(200, 145), Width = 400, DropDownStyle = ComboBoxStyle.DropDownList };
            cboLoaiThuong.Items.AddRange(new object[] {
                "Thưởng thành tích", "Thưởng lễ", "Lương tháng 13", "Thưởng cuối năm" });
            cboLoaiThuong.SelectedIndex = 0;
            Controls.Add(cboLoaiThuong);

            Lbl("Nội dung:", 20, 188);
            txtNoiDung = new TextBox { Location = new Point(200, 185), Width = 600, Height = 70, Multiline = true };
            Controls.Add(txtNoiDung);

            Lbl("Số tiền (VNĐ):", 20, 273);
            txtSoTien = new TextBox { Location = new Point(200, 270), Width = 200 };
            Controls.Add(txtSoTien);

            Lbl("Ngày quyết định:", 20, 313);
            dtpNgayQD = new DateTimePicker { Location = new Point(200, 310), Width = 200, Format = DateTimePickerFormat.Short };
            Controls.Add(dtpNgayQD);

            btnLuu = new Button { Text = "Lưu quyết định", Location = new Point(200, 355), Size = new Size(160, 36) };
            btnLamMoi = new Button { Text = "Làm mới", Location = new Point(375, 355), Size = new Size(120, 36) };
            Controls.Add(btnLuu);
            Controls.Add(btnLamMoi);
            btnKyDuyet = new Button { Text = "Mở form ký duyệt", Location = new Point(510, 355), Size = new Size(170, 36) };
            Controls.Add(btnKyDuyet);
            btnKyDuyet.Click += (s, e) => { new FormKyDuyet().ShowDialog(); LoadDanhSach(); };
            Lbl("Quyết định gần đây:", 20, 408, true);
            dgv = new DataGridView
            {
                Location = new Point(20, 438),
                Size = new Size(860, 185),
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };
            Controls.Add(dgv);

            // Gắn sự kiện sau cùng để không chạy khi đang dựng giao diện
            rdoCaNhan.CheckedChanged += (s, e) => { if (((RadioButton)s).Checked) LoadDoiTuong(); };
            rdoTapThe.CheckedChanged += (s, e) => { if (((RadioButton)s).Checked) LoadDoiTuong(); };
            btnLuu.Click += (s, e) => Luu();
            btnLamMoi.Click += (s, e) => LamMoi();
        }

        // ---------- Nạp dữ liệu ----------
        void LoadDoiTuong()
        {
            bool caNhan = rdoCaNhan.Checked;
            lblDoiTuong.Text = caNhan ? "Nhân viên:" : "Phòng ban:";
            string sql = caNhan
                ? "SELECT maNV AS ma, maNV + N' - ' + hoTen AS hienThi FROM NhanVien ORDER BY maNV"
                : "SELECT maPB AS ma, maPB + N' - ' + tenPB AS hienThi FROM PhongBan ORDER BY maPB";
            try
            {
                var dt = new DataTable();
                using (var da = new SqlDataAdapter(sql, Db.ConnStr)) da.Fill(dt);
                cboDoiTuong.DataSource = null;
                cboDoiTuong.DisplayMember = "hienThi";
                cboDoiTuong.ValueMember = "ma";
                cboDoiTuong.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối CSDL:\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void LoadDanhSach()
        {
            const string sql =
                "SELECT TOP 20 maQD, loaiDoiTuong, ISNULL(maNV, maPB) AS doiTuong, loaiThuong, soTien, ngayQD, trangThai " +
                "FROM QuyetDinhKhenThuong ORDER BY maQD DESC";
            try
            {
                var dt = new DataTable();
                using (var da = new SqlDataAdapter(sql, Db.ConnStr)) da.Fill(dt);
                dgv.DataSource = dt;
                dgv.Columns["maQD"].HeaderText = "Mã QĐ";
                dgv.Columns["loaiDoiTuong"].HeaderText = "Loại đối tượng";
                dgv.Columns["doiTuong"].HeaderText = "Đối tượng";
                dgv.Columns["loaiThuong"].HeaderText = "Loại thưởng";
                dgv.Columns["soTien"].HeaderText = "Số tiền";
                dgv.Columns["soTien"].DefaultCellStyle.Format = "N0";
                dgv.Columns["ngayQD"].HeaderText = "Ngày QĐ";
                dgv.Columns["ngayQD"].DefaultCellStyle.Format = "dd/MM/yyyy";
                dgv.Columns["trangThai"].HeaderText = "Trạng thái";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nạp danh sách:\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void LamMoi()
        {
            txtNoiDung.Clear();
            txtSoTien.Clear();
            cboLoaiThuong.SelectedIndex = 0;
            dtpNgayQD.Value = DateTime.Today;
            if (cboDoiTuong.Items.Count > 0) cboDoiTuong.SelectedIndex = 0;
        }

        // ---------- Lưu quyết định (có transaction) ----------
        void Luu()
        {
            if (cboDoiTuong.SelectedValue == null)
            {
                MessageBox.Show("Vui lòng chọn đối tượng khen thưởng.", "Thiếu thông tin",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtNoiDung.Text))
            {
                MessageBox.Show("Vui lòng nhập nội dung quyết định.", "Thiếu thông tin",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNoiDung.Focus();
                return;
            }
            string raw = txtSoTien.Text.Replace(".", "").Replace(",", "").Trim();
            decimal soTien;
            if (!decimal.TryParse(raw, NumberStyles.None, CultureInfo.InvariantCulture, out soTien) || soTien <= 0)
            {
                MessageBox.Show("Số tiền phải là số nguyên dương.", "Sai dữ liệu",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSoTien.Focus();
                return;
            }

            bool caNhan = rdoCaNhan.Checked;
            string ma = cboDoiTuong.SelectedValue.ToString();

            using (var cn = new SqlConnection(Db.ConnStr))
            {
                try
                {
                    cn.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi kết nối CSDL:\n" + ex.Message, "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                using (var tran = cn.BeginTransaction())          // beginTransaction()
                {
                    try
                    {
                        // Sinh mã QD kế tiếp: QD001, QD002, ...
                        string maQD;
                        using (var cmdMa = new SqlCommand(
                            "SELECT ISNULL(MAX(CAST(SUBSTRING(maQD,3,10) AS INT)),0)+1 " +
                            "FROM QuyetDinhKhenThuong WITH (UPDLOCK, HOLDLOCK)", cn, tran))
                        {
                            maQD = "QD" + Convert.ToInt32(cmdMa.ExecuteScalar()).ToString("000");
                        }

                        const string sqlIns =
                            "INSERT INTO QuyetDinhKhenThuong " +
                            "(maQD, loaiDoiTuong, maNV, maPB, loaiThuong, noiDung, soTien, ngayQD, trangThai) " +
                            "VALUES (@maQD, @loai, @maNV, @maPB, @loaiThuong, @noiDung, @soTien, @ngay, N'ChoDuyet')";

                        using (var cmd = new SqlCommand(sqlIns, cn, tran))   // INSERT QuyetDinhKhenThuong
                        {
                            cmd.Parameters.Add("@maQD", SqlDbType.VarChar, 10).Value = maQD;
                            cmd.Parameters.Add("@loai", SqlDbType.NVarChar, 20).Value = caNhan ? "CaNhan" : "TapThe";
                            cmd.Parameters.Add("@maNV", SqlDbType.VarChar, 10).Value = caNhan ? (object)ma : DBNull.Value;
                            cmd.Parameters.Add("@maPB", SqlDbType.VarChar, 10).Value = caNhan ? DBNull.Value : (object)ma;
                            cmd.Parameters.Add("@loaiThuong", SqlDbType.NVarChar, 50).Value = cboLoaiThuong.Text;
                            cmd.Parameters.Add("@noiDung", SqlDbType.NVarChar, 500).Value = txtNoiDung.Text.Trim();
                            var pTien = cmd.Parameters.Add("@soTien", SqlDbType.Decimal);
                            pTien.Precision = 18;
                            pTien.Scale = 0;
                            pTien.Value = soTien;
                            cmd.Parameters.Add("@ngay", SqlDbType.Date).Value = dtpNgayQD.Value.Date;
                            cmd.ExecuteNonQuery();
                        }

                        tran.Commit();                                   // commit()
                        MessageBox.Show("Đã lưu quyết định " + maQD + " (trạng thái: Chờ duyệt).\n" +
                                        "Quyết định này đang chờ Giám đốc ký duyệt.",
                            "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LamMoi();
                        LoadDanhSach();
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();                                 // rollback()
                        MessageBox.Show("Lưu thất bại, đã hoàn tác:\n" + ex.Message, "Lỗi",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}