﻿using QuanLyNhanSu;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormKyDuyet : Form
    {
        DataGridView dgv;
        TextBox txtChiTiet;
        Button btnDuyet, btnTuChoi, btnLamMoi, btnDong;

        public FormKyDuyet()
        {
            InitializeComponent();
            DungGiaoDien();
            LoadDanhSach();
        }

        // ---------- Giao diện (dựng bằng code) ----------
        Label Lbl(string text, int x, int y, bool bold = false, float size = 10)
        {
            var l = new Label();
            l.Text = text;
            l.AutoSize = true;
            l.Location = new Point(x, y);
            l.Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular);
            Controls.Add(l);
            return l;
        }

        void DungGiaoDien()
        {
            Text = "Ký duyệt quyết định khen thưởng";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(900, 540);
            Font = new Font("Segoe UI", 10);

            Lbl("KÝ DUYỆT QUYẾT ĐỊNH KHEN THƯỞNG", 20, 15, true, 16);
            Lbl("Danh sách quyết định đang chờ duyệt:", 20, 62, true);

            dgv = new DataGridView
            {
                Location = new Point(20, 92),
                Size = new Size(860, 220),
                ReadOnly = true,
                AllowUserToAddRows = false,
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };
            Controls.Add(dgv);

            Lbl("Nội dung quyết định:", 20, 325, true);
            txtChiTiet = new TextBox
            {
                Location = new Point(20, 355),
                Size = new Size(860, 90),
                Multiline = true,
                ReadOnly = true
            };
            Controls.Add(txtChiTiet);

            btnDuyet = new Button { Text = "Duyệt", Location = new Point(20, 470), Size = new Size(140, 38) };
            btnTuChoi = new Button { Text = "Từ chối", Location = new Point(175, 470), Size = new Size(140, 38) };
            btnLamMoi = new Button { Text = "Làm mới", Location = new Point(330, 470), Size = new Size(140, 38) };
            btnDong = new Button { Text = "Đóng", Location = new Point(740, 470), Size = new Size(140, 38) };
            Controls.Add(btnDuyet);
            Controls.Add(btnTuChoi);
            Controls.Add(btnLamMoi);
            Controls.Add(btnDong);

            dgv.SelectionChanged += (s, e) => HienChiTiet();
            btnDuyet.Click += (s, e) => Duyet();
            btnTuChoi.Click += (s, e) => TuChoi();
            btnLamMoi.Click += (s, e) => LoadDanhSach();
            btnDong.Click += (s, e) => Close();
        }

        // ---------- Nạp dữ liệu ----------
        void LoadDanhSach()
        {
            const string sql =
                "SELECT q.maQD, q.loaiDoiTuong, " +
                "  CASE WHEN q.loaiDoiTuong = N'CaNhan' " +
                "       THEN q.maNV + N' - ' + nv.hoTen " +
                "       ELSE q.maPB + N' - ' + pb.tenPB END AS doiTuong, " +
                "  q.loaiThuong, q.soTien, q.ngayQD, q.noiDung " +
                "FROM QuyetDinhKhenThuong q " +
                "LEFT JOIN NhanVien nv ON q.maNV = nv.maNV " +
                "LEFT JOIN PhongBan pb ON q.maPB = pb.maPB " +
                "WHERE q.trangThai = N'ChoDuyet' " +
                "ORDER BY q.maQD";
            try
            {
                var dt = new DataTable();
                using (var da = new SqlDataAdapter(sql, Db.ConnStr)) da.Fill(dt);
                dgv.DataSource = dt;
                dgv.Columns["maQD"].HeaderText = "Mã QĐ";
                dgv.Columns["loaiDoiTuong"].HeaderText = "Loại đối tượng";
                dgv.Columns["doiTuong"].HeaderText = "Đối tượng";
                dgv.Columns["loaiThuong"].HeaderText = "Loại thưởng";
                dgv.Columns["soTien"].HeaderText = "Số tiền";
                dgv.Columns["soTien"].DefaultCellStyle.Format = "N0";
                dgv.Columns["ngayQD"].HeaderText = "Ngày QĐ";
                dgv.Columns["ngayQD"].DefaultCellStyle.Format = "dd/MM/yyyy";
                dgv.Columns["noiDung"].Visible = false;
                HienChiTiet();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nạp danh sách:\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void HienChiTiet()
        {
            if (!dgv.Columns.Contains("noiDung") || dgv.CurrentRow == null
                || dgv.CurrentRow.Cells["noiDung"].Value == null)
            {
                txtChiTiet.Clear();
                return;
            }
            txtChiTiet.Text = dgv.CurrentRow.Cells["noiDung"].Value.ToString();
        }

        string LayMaQD()
        {
            if (dgv.CurrentRow == null || dgv.CurrentRow.Cells["maQD"].Value == null)
            {
                MessageBox.Show("Không có quyết định nào để xử lý. Hãy chọn một dòng trong danh sách.",
                    "Chưa chọn", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }
            return dgv.CurrentRow.Cells["maQD"].Value.ToString();
        }

        SqlConnection MoKetNoi()
        {
            var cn = new SqlConnection(Db.ConnStr);
            try
            {
                cn.Open();
                return cn;
            }
            catch (Exception ex)
            {
                cn.Dispose();
                MessageBox.Show("Lỗi kết nối CSDL:\n" + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        // ---------- Duyệt: cập nhật trạng thái + tạo phiếu chi (1 transaction) ----------
        void Duyet()
        {
            string maQD = LayMaQD();
            if (maQD == null) return;

            if (MessageBox.Show("Ký duyệt quyết định " + maQD + " và lập phiếu chi khen thưởng?",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            using (var cn = MoKetNoi())
            {
                if (cn == null) return;
                using (var tran = cn.BeginTransaction())              // beginTransaction()
                {
                    try
                    {
                        // 1. capNhatTrangThai("DaDuyet")
                        int n;
                        using (var cmd = new SqlCommand(
                            "UPDATE QuyetDinhKhenThuong SET trangThai = N'DaDuyet' " +
                            "WHERE maQD = @maQD AND trangThai = N'ChoDuyet'", cn, tran))
                        {
                            cmd.Parameters.Add("@maQD", SqlDbType.VarChar, 10).Value = maQD;
                            n = cmd.ExecuteNonQuery();
                        }
                        if (n == 0)
                            throw new Exception("Quyết định này đã được xử lý trước đó hoặc không tồn tại.");

                        // 2. Lấy số tiền của quyết định
                        decimal soTien;
                        using (var cmd = new SqlCommand(
                            "SELECT soTien FROM QuyetDinhKhenThuong WHERE maQD = @maQD", cn, tran))
                        {
                            cmd.Parameters.Add("@maQD", SqlDbType.VarChar, 10).Value = maQD;
                            soTien = Convert.ToDecimal(cmd.ExecuteScalar());
                        }

                        // 3. Sinh mã phiếu chi kế tiếp: PC001, PC002, ...
                        string maPC;
                        using (var cmd = new SqlCommand(
                            "SELECT ISNULL(MAX(CAST(SUBSTRING(maPC,3,10) AS INT)),0)+1 " +
                            "FROM PhieuChiKhenThuong WITH (UPDLOCK, HOLDLOCK)", cn, tran))
                        {
                            maPC = "PC" + Convert.ToInt32(cmd.ExecuteScalar()).ToString("000");
                        }

                        // 4. INSERT PhieuChiKhenThuong (mỗi quyết định đúng 1 phiếu chi)
                        using (var cmd = new SqlCommand(
                            "INSERT INTO PhieuChiKhenThuong (maPC, maQD, soTien, ngayChi) " +
                            "VALUES (@maPC, @maQD, @soTien, @ngay)", cn, tran))
                        {
                            cmd.Parameters.Add("@maPC", SqlDbType.VarChar, 10).Value = maPC;
                            cmd.Parameters.Add("@maQD", SqlDbType.VarChar, 10).Value = maQD;
                            var pTien = cmd.Parameters.Add("@soTien", SqlDbType.Decimal);
                            pTien.Precision = 18;
                            pTien.Scale = 0;
                            pTien.Value = soTien;
                            cmd.Parameters.Add("@ngay", SqlDbType.Date).Value = DateTime.Today;
                            cmd.ExecuteNonQuery();
                        }

                        tran.Commit();                                  // commit()
                        MessageBox.Show("Đã ký duyệt quyết định " + maQD + ".\nĐã lập phiếu chi " + maPC + ".",
                            "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDanhSach();
                    }
                    catch (Exception ex)
                    {
                        try { tran.Rollback(); } catch { }              // rollback()
                        MessageBox.Show("Duyệt thất bại, đã hoàn tác:\n" + ex.Message, "Lỗi",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // ---------- Từ chối: chỉ đổi trạng thái, không tạo phiếu chi ----------
        void TuChoi()
        {
            string maQD = LayMaQD();
            if (maQD == null) return;

            if (MessageBox.Show("Từ chối quyết định " + maQD + "?",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            using (var cn = MoKetNoi())
            {
                if (cn == null) return;
                using (var tran = cn.BeginTransaction())
                {
                    try
                    {
                        int n;
                        using (var cmd = new SqlCommand(
                            "UPDATE QuyetDinhKhenThuong SET trangThai = N'TuChoi' " +
                            "WHERE maQD = @maQD AND trangThai = N'ChoDuyet'", cn, tran))
                        {
                            cmd.Parameters.Add("@maQD", SqlDbType.VarChar, 10).Value = maQD;
                            n = cmd.ExecuteNonQuery();
                        }
                        if (n == 0)
                            throw new Exception("Quyết định này đã được xử lý trước đó hoặc không tồn tại.");

                        tran.Commit();
                        MessageBox.Show("Đã từ chối quyết định " + maQD + ".",
                            "Hoàn tất", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDanhSach();
                    }
                    catch (Exception ex)
                    {
                        try { tran.Rollback(); } catch { }
                        MessageBox.Show("Từ chối thất bại:\n" + ex.Message, "Lỗi",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}