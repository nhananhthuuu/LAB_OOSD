﻿namespace QuanLyNhanSu
{
    static class Db
    {
        public const string ConnStr =
            "Server=localhost;Database=QuanLyNhanSu_DongA;Integrated Security=True;TrustServerCertificate=True;";
    }
}