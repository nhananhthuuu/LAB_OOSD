﻿namespace QuanLyKhachSan
{
    partial class FrmTraPhong
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.lblSoPhieu = new System.Windows.Forms.Label();
            this.txtSoPhieuDat = new System.Windows.Forms.TextBox();
            this.btnTim = new System.Windows.Forms.Button();

            this.lblPhong = new System.Windows.Forms.Label();
            this.txtSoPhong = new System.Windows.Forms.TextBox();

            this.lblNgayTra = new System.Windows.Forms.Label();
            this.dtNgayTra = new System.Windows.Forms.DateTimePicker();

            this.lblSoNgay = new System.Windows.Forms.Label();
            this.txtSoNgay = new System.Windows.Forms.TextBox();

            this.dgvDichVu = new System.Windows.Forms.DataGridView();

            this.lblTienPhong = new System.Windows.Forms.Label();
            this.txtTienPhong = new System.Windows.Forms.TextBox();

            this.lblTienDichVu = new System.Windows.Forms.Label();
            this.txtTienDichVu = new System.Windows.Forms.TextBox();

            this.lblTienDenBu = new System.Windows.Forms.Label();
            this.txtTienDenBu = new System.Windows.Forms.TextBox();

            this.lblTongTien = new System.Windows.Forms.Label();
            this.txtTongTien = new System.Windows.Forms.TextBox();

            this.groupBoxDenBu = new System.Windows.Forms.GroupBox();

            this.lblMaTienNghi = new System.Windows.Forms.Label();
            this.txtMaTienNghi = new System.Windows.Forms.TextBox();

            this.lblMucDo = new System.Windows.Forms.Label();
            this.txtMucDo = new System.Windows.Forms.TextBox();

            this.lblSoTien = new System.Windows.Forms.Label();
            this.txtSoTien = new System.Windows.Forms.TextBox();

            this.btnThemDenBu = new System.Windows.Forms.Button();

            this.lblHinhThuc = new System.Windows.Forms.Label();
            this.cboHinhThuc = new System.Windows.Forms.ComboBox();

            this.btnLapHoaDon = new System.Windows.Forms.Button();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnMoi = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvDichVu)).BeginInit();
            this.groupBoxDenBu.SuspendLayout();
            this.SuspendLayout();

            // lblTieuDe
            this.lblTieuDe.Font = new System.Drawing.Font(
                "Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.Location = new System.Drawing.Point(20, 15);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(850, 40);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "TRẢ PHÒNG - HÓA ĐƠN - THANH TOÁN";
            this.lblTieuDe.TextAlign =
                System.Drawing.ContentAlignment.MiddleCenter;

            // lblSoPhieu
            this.lblSoPhieu.AutoSize = true;
            this.lblSoPhieu.Location = new System.Drawing.Point(30, 75);
            this.lblSoPhieu.Name = "lblSoPhieu";
            this.lblSoPhieu.Size = new System.Drawing.Size(90, 20);
            this.lblSoPhieu.Text = "Số phiếu đặt:";

            // txtSoPhieuDat
            this.txtSoPhieuDat.Location =
                new System.Drawing.Point(130, 70);
            this.txtSoPhieuDat.Name = "txtSoPhieuDat";
            this.txtSoPhieuDat.Size =
                new System.Drawing.Size(180, 27);

            // btnTim
            this.btnTim.Location =
                new System.Drawing.Point(325, 68);
            this.btnTim.Name = "btnTim";
            this.btnTim.Size =
                new System.Drawing.Size(100, 32);
            this.btnTim.Text = "Tìm";
            this.btnTim.UseVisualStyleBackColor = true;
            this.btnTim.Click +=
                new System.EventHandler(this.btnTim_Click);

            // lblPhong
            this.lblPhong.AutoSize = true;
            this.lblPhong.Location =
                new System.Drawing.Point(450, 75);
            this.lblPhong.Text = "Phòng:";

            // txtSoPhong
            this.txtSoPhong.Location =
                new System.Drawing.Point(510, 70);
            this.txtSoPhong.Name = "txtSoPhong";
            this.txtSoPhong.Size =
                new System.Drawing.Size(130, 27);
            this.txtSoPhong.ReadOnly = true;

            // lblNgayTra
            this.lblNgayTra.AutoSize = true;
            this.lblNgayTra.Location =
                new System.Drawing.Point(670, 75);
            this.lblNgayTra.Text = "Ngày trả:";

            // dtNgayTra
            this.dtNgayTra.Format =
                System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNgayTra.Location =
                new System.Drawing.Point(740, 70);
            this.dtNgayTra.Name = "dtNgayTra";
            this.dtNgayTra.Size =
                new System.Drawing.Size(130, 27);

            // lblSoNgay
            this.lblSoNgay.AutoSize = true;
            this.lblSoNgay.Location =
                new System.Drawing.Point(30, 120);
            this.lblSoNgay.Text = "Số ngày:";

            // txtSoNgay
            this.txtSoNgay.Location =
                new System.Drawing.Point(130, 115);
            this.txtSoNgay.Name = "txtSoNgay";
            this.txtSoNgay.Size =
                new System.Drawing.Size(180, 27);
            this.txtSoNgay.ReadOnly = true;

            // dgvDichVu
            this.dgvDichVu.AllowUserToAddRows = false;
            this.dgvDichVu.AllowUserToDeleteRows = false;
            this.dgvDichVu.ColumnHeadersHeightSizeMode =
                System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDichVu.Location =
                new System.Drawing.Point(30, 160);
            this.dgvDichVu.Name = "dgvDichVu";
            this.dgvDichVu.ReadOnly = true;
            this.dgvDichVu.RowHeadersWidth = 30;
            this.dgvDichVu.SelectionMode =
                System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDichVu.Size =
                new System.Drawing.Size(840, 150);
            this.dgvDichVu.TabIndex = 10;

            // lblTienPhong
            this.lblTienPhong.AutoSize = true;
            this.lblTienPhong.Location =
                new System.Drawing.Point(30, 330);
            this.lblTienPhong.Text = "Tiền phòng:";

            // txtTienPhong
            this.txtTienPhong.Location =
                new System.Drawing.Point(130, 325);
            this.txtTienPhong.Name = "txtTienPhong";
            this.txtTienPhong.Size =
                new System.Drawing.Size(180, 27);
            this.txtTienPhong.ReadOnly = true;

            // lblTienDichVu
            this.lblTienDichVu.AutoSize = true;
            this.lblTienDichVu.Location =
                new System.Drawing.Point(340, 330);
            this.lblTienDichVu.Text = "Tiền dịch vụ:";

            // txtTienDichVu
            this.txtTienDichVu.Location =
                new System.Drawing.Point(440, 325);
            this.txtTienDichVu.Name = "txtTienDichVu";
            this.txtTienDichVu.Size =
                new System.Drawing.Size(180, 27);
            this.txtTienDichVu.ReadOnly = true;

            // lblTienDenBu
            this.lblTienDenBu.AutoSize = true;
            this.lblTienDenBu.Location =
                new System.Drawing.Point(650, 330);
            this.lblTienDenBu.Text = "Tiền đền bù:";

            // txtTienDenBu
            this.txtTienDenBu.Location =
                new System.Drawing.Point(740, 325);
            this.txtTienDenBu.Name = "txtTienDenBu";
            this.txtTienDenBu.Size =
                new System.Drawing.Size(130, 27);
            this.txtTienDenBu.ReadOnly = true;

            // groupBoxDenBu
            this.groupBoxDenBu.Controls.Add(this.lblMaTienNghi);
            this.groupBoxDenBu.Controls.Add(this.txtMaTienNghi);
            this.groupBoxDenBu.Controls.Add(this.lblMucDo);
            this.groupBoxDenBu.Controls.Add(this.txtMucDo);
            this.groupBoxDenBu.Controls.Add(this.lblSoTien);
            this.groupBoxDenBu.Controls.Add(this.txtSoTien);
            this.groupBoxDenBu.Controls.Add(this.btnThemDenBu);

            this.groupBoxDenBu.Location =
                new System.Drawing.Point(30, 370);
            this.groupBoxDenBu.Name = "groupBoxDenBu";
            this.groupBoxDenBu.Size =
                new System.Drawing.Size(840, 85);
            this.groupBoxDenBu.Text = "Đền bù / Hư hỏng";

            // lblMaTienNghi
            this.lblMaTienNghi.AutoSize = true;
            this.lblMaTienNghi.Location =
                new System.Drawing.Point(15, 35);
            this.lblMaTienNghi.Text = "Tiện nghi:";

            // txtMaTienNghi
            this.txtMaTienNghi.Location =
                new System.Drawing.Point(80, 30);
            this.txtMaTienNghi.Name = "txtMaTienNghi";
            this.txtMaTienNghi.Size =
                new System.Drawing.Size(150, 27);

            // lblMucDo
            this.lblMucDo.AutoSize = true;
            this.lblMucDo.Location =
                new System.Drawing.Point(250, 35);
            this.lblMucDo.Text = "Mức độ:";

            // txtMucDo
            this.txtMucDo.Location =
                new System.Drawing.Point(310, 30);
            this.txtMucDo.Name = "txtMucDo";
            this.txtMucDo.Size =
                new System.Drawing.Size(180, 27);

            // lblSoTien
            this.lblSoTien.AutoSize = true;
            this.lblSoTien.Location =
                new System.Drawing.Point(505, 35);
            this.lblSoTien.Text = "Số tiền:";

            // txtSoTien
            this.txtSoTien.Location =
                new System.Drawing.Point(560, 30);
            this.txtSoTien.Name = "txtSoTien";
            this.txtSoTien.Size =
                new System.Drawing.Size(120, 27);

            // btnThemDenBu
            this.btnThemDenBu.Location =
                new System.Drawing.Point(690, 28);
            this.btnThemDenBu.Name = "btnThemDenBu";
            this.btnThemDenBu.Size =
                new System.Drawing.Size(120, 32);
            this.btnThemDenBu.Text = "Thêm đền bù";
            this.btnThemDenBu.UseVisualStyleBackColor = true;
            this.btnThemDenBu.Click +=
                new System.EventHandler(this.btnThemDenBu_Click);

            // lblTongTien
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font =
                new System.Drawing.Font(
                    "Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTongTien.Location =
                new System.Drawing.Point(500, 475);
            this.lblTongTien.Text = "TỔNG TIỀN:";

            // txtTongTien
            this.txtTongTien.Font =
                new System.Drawing.Font(
                    "Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.txtTongTien.Location =
                new System.Drawing.Point(620, 470);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Size =
                new System.Drawing.Size(250, 34);
            this.txtTongTien.ReadOnly = true;

            // lblHinhThuc
            this.lblHinhThuc.AutoSize = true;
            this.lblHinhThuc.Location =
                new System.Drawing.Point(30, 480);
            this.lblHinhThuc.Text = "Hình thức:";

            // cboHinhThuc
            this.cboHinhThuc.DropDownStyle =
                System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHinhThuc.FormattingEnabled = true;
            this.cboHinhThuc.Items.AddRange(
                new object[]
                {
                    "Tiền mặt",
                    "Chuyển khoản",
                    "Thẻ",
                    "Ví điện tử"
                });
            this.cboHinhThuc.Location =
                new System.Drawing.Point(100, 475);
            this.cboHinhThuc.Name = "cboHinhThuc";
            this.cboHinhThuc.Size =
                new System.Drawing.Size(180, 28);

            // btnLapHoaDon
            this.btnLapHoaDon.Location =
                new System.Drawing.Point(30, 525);
            this.btnLapHoaDon.Name = "btnLapHoaDon";
            this.btnLapHoaDon.Size =
                new System.Drawing.Size(180, 40);
            this.btnLapHoaDon.Text = "Lập hóa đơn";
            this.btnLapHoaDon.UseVisualStyleBackColor = true;
            this.btnLapHoaDon.Click +=
                new System.EventHandler(this.btnLapHoaDon_Click);

            // btnThanhToan
            this.btnThanhToan.Location =
                new System.Drawing.Point(230, 525);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size =
                new System.Drawing.Size(180, 40);
            this.btnThanhToan.Text = "Thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click +=
                new System.EventHandler(this.btnThanhToan_Click);

            // btnMoi
            this.btnMoi.Location =
                new System.Drawing.Point(430, 525);
            this.btnMoi.Name = "btnMoi";
            this.btnMoi.Size =
                new System.Drawing.Size(150, 40);
            this.btnMoi.Text = "Làm mới";
            this.btnMoi.UseVisualStyleBackColor = true;
            this.btnMoi.Click +=
                new System.EventHandler(this.btnMoi_Click);

            // btnDong
            this.btnDong.Location =
                new System.Drawing.Point(590, 525);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size =
                new System.Drawing.Size(150, 40);
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click +=
                new System.EventHandler(this.btnDong_Click);

            // FrmTraPhong
            this.AutoScaleDimensions =
                new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize =
                new System.Drawing.Size(900, 590);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnMoi);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.btnLapHoaDon);
            this.Controls.Add(this.cboHinhThuc);
            this.Controls.Add(this.lblHinhThuc);
            this.Controls.Add(this.txtTongTien);
            this.Controls.Add(this.lblTongTien);
            this.Controls.Add(this.groupBoxDenBu);
            this.Controls.Add(this.txtTienDenBu);
            this.Controls.Add(this.lblTienDenBu);
            this.Controls.Add(this.txtTienDichVu);
            this.Controls.Add(this.lblTienDichVu);
            this.Controls.Add(this.txtTienPhong);
            this.Controls.Add(this.lblTienPhong);
            this.Controls.Add(this.dgvDichVu);
            this.Controls.Add(this.txtSoNgay);
            this.Controls.Add(this.lblSoNgay);
            this.Controls.Add(this.dtNgayTra);
            this.Controls.Add(this.lblNgayTra);
            this.Controls.Add(this.txtSoPhong);
            this.Controls.Add(this.lblPhong);
            this.Controls.Add(this.btnTim);
            this.Controls.Add(this.txtSoPhieuDat);
            this.Controls.Add(this.lblSoPhieu);
            this.Controls.Add(this.lblTieuDe);

            this.Font =
                new System.Drawing.Font("Segoe UI", 10F);
            this.FormBorderStyle =
                System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmTraPhong";
            this.StartPosition =
                System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trả phòng - Thanh toán";

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvDichVu)).EndInit();

            this.groupBoxDenBu.ResumeLayout(false);
            this.groupBoxDenBu.PerformLayout();

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Label lblSoPhieu;
        private System.Windows.Forms.TextBox txtSoPhieuDat;
        private System.Windows.Forms.Button btnTim;

        private System.Windows.Forms.Label lblPhong;
        private System.Windows.Forms.TextBox txtSoPhong;

        private System.Windows.Forms.Label lblNgayTra;
        private System.Windows.Forms.DateTimePicker dtNgayTra;

        private System.Windows.Forms.Label lblSoNgay;
        private System.Windows.Forms.TextBox txtSoNgay;

        private System.Windows.Forms.DataGridView dgvDichVu;

        private System.Windows.Forms.Label lblTienPhong;
        private System.Windows.Forms.TextBox txtTienPhong;

        private System.Windows.Forms.Label lblTienDichVu;
        private System.Windows.Forms.TextBox txtTienDichVu;

        private System.Windows.Forms.Label lblTienDenBu;
        private System.Windows.Forms.TextBox txtTienDenBu;

        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.TextBox txtTongTien;

        private System.Windows.Forms.GroupBox groupBoxDenBu;

        private System.Windows.Forms.Label lblMaTienNghi;
        private System.Windows.Forms.TextBox txtMaTienNghi;

        private System.Windows.Forms.Label lblMucDo;
        private System.Windows.Forms.TextBox txtMucDo;

        private System.Windows.Forms.Label lblSoTien;
        private System.Windows.Forms.TextBox txtSoTien;

        private System.Windows.Forms.Button btnThemDenBu;

        private System.Windows.Forms.Label lblHinhThuc;
        private System.Windows.Forms.ComboBox cboHinhThuc;

        private System.Windows.Forms.Button btnLapHoaDon;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnMoi;
        private System.Windows.Forms.Button btnDong;
    }
}