﻿namespace QuanLyKhachSan
{
    partial class FrmThongKe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();

            this.grpTongQuan =
                new System.Windows.Forms.GroupBox();

            this.lblTongPhong =
                new System.Windows.Forms.Label();

            this.lblTongPhongValue =
                new System.Windows.Forms.Label();

            this.lblPhongTrong =
                new System.Windows.Forms.Label();

            this.lblPhongTrongValue =
                new System.Windows.Forms.Label();

            this.lblPhongDaDat =
                new System.Windows.Forms.Label();

            this.lblPhongDaDatValue =
                new System.Windows.Forms.Label();

            this.lblPhongDangO =
                new System.Windows.Forms.Label();

            this.lblPhongDangOValue =
                new System.Windows.Forms.Label();

            this.lblTongKhach =
                new System.Windows.Forms.Label();

            this.lblTongKhachValue =
                new System.Windows.Forms.Label();

            this.lblTongPhieuDat =
                new System.Windows.Forms.Label();

            this.lblTongPhieuDatValue =
                new System.Windows.Forms.Label();

            this.lblTongDichVu =
                new System.Windows.Forms.Label();

            this.lblTongDichVuValue =
                new System.Windows.Forms.Label();

            this.lblTongDenBu =
                new System.Windows.Forms.Label();

            this.lblTongDenBuValue =
                new System.Windows.Forms.Label();

            this.dgvThongKe =
                new System.Windows.Forms.DataGridView();

            this.btnLamMoi =
                new System.Windows.Forms.Button();

            this.btnDong =
                new System.Windows.Forms.Button();

            this.grpTongQuan.SuspendLayout();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvThongKe)).BeginInit();

            this.SuspendLayout();

            // ==========================================
            // TIÊU ĐỀ
            // ==========================================

            this.lblTieuDe.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    18F,
                    System.Drawing.FontStyle.Bold);

            this.lblTieuDe.Location =
                new System.Drawing.Point(20, 15);

            this.lblTieuDe.Name =
                "lblTieuDe";

            this.lblTieuDe.Size =
                new System.Drawing.Size(850, 40);

            this.lblTieuDe.Text =
                "THỐNG KÊ KHÁCH SẠN";

            this.lblTieuDe.TextAlign =
                System.Drawing.ContentAlignment.MiddleCenter;

            // ==========================================
            // GROUP TỔNG QUAN
            // ==========================================

            this.grpTongQuan.Controls.Add(
                this.lblTongPhong);

            this.grpTongQuan.Controls.Add(
                this.lblTongPhongValue);

            this.grpTongQuan.Controls.Add(
                this.lblPhongTrong);

            this.grpTongQuan.Controls.Add(
                this.lblPhongTrongValue);

            this.grpTongQuan.Controls.Add(
                this.lblPhongDaDat);

            this.grpTongQuan.Controls.Add(
                this.lblPhongDaDatValue);

            this.grpTongQuan.Controls.Add(
                this.lblPhongDangO);

            this.grpTongQuan.Controls.Add(
                this.lblPhongDangOValue);

            this.grpTongQuan.Controls.Add(
                this.lblTongKhach);

            this.grpTongQuan.Controls.Add(
                this.lblTongKhachValue);

            this.grpTongQuan.Controls.Add(
                this.lblTongPhieuDat);

            this.grpTongQuan.Controls.Add(
                this.lblTongPhieuDatValue);

            this.grpTongQuan.Controls.Add(
                this.lblTongDichVu);

            this.grpTongQuan.Controls.Add(
                this.lblTongDichVuValue);

            this.grpTongQuan.Controls.Add(
                this.lblTongDenBu);

            this.grpTongQuan.Controls.Add(
                this.lblTongDenBuValue);

            this.grpTongQuan.Location =
                new System.Drawing.Point(30, 70);

            this.grpTongQuan.Name =
                "grpTongQuan";

            this.grpTongQuan.Size =
                new System.Drawing.Size(840, 170);

            this.grpTongQuan.Text =
                "Tổng quan";

            // ==========================================
            // TỔNG PHÒNG
            // ==========================================

            this.lblTongPhong.AutoSize = true;
            this.lblTongPhong.Location =
                new System.Drawing.Point(20, 35);

            this.lblTongPhong.Text =
                "Tổng số phòng:";

            this.lblTongPhongValue.AutoSize = true;
            this.lblTongPhongValue.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    11F,
                    System.Drawing.FontStyle.Bold);

            this.lblTongPhongValue.Location =
                new System.Drawing.Point(145, 33);

            this.lblTongPhongValue.Text =
                "0";

            // ==========================================
            // PHÒNG TRỐNG
            // ==========================================

            this.lblPhongTrong.AutoSize = true;
            this.lblPhongTrong.Location =
                new System.Drawing.Point(220, 35);

            this.lblPhongTrong.Text =
                "Phòng trống:";

            this.lblPhongTrongValue.AutoSize = true;
            this.lblPhongTrongValue.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    11F,
                    System.Drawing.FontStyle.Bold);

            this.lblPhongTrongValue.Location =
                new System.Drawing.Point(320, 33);

            this.lblPhongTrongValue.Text =
                "0";

            // ==========================================
            // PHÒNG ĐÃ ĐẶT
            // ==========================================

            this.lblPhongDaDat.AutoSize = true;
            this.lblPhongDaDat.Location =
                new System.Drawing.Point(400, 35);

            this.lblPhongDaDat.Text =
                "Đã đặt:";

            this.lblPhongDaDatValue.AutoSize = true;
            this.lblPhongDaDatValue.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    11F,
                    System.Drawing.FontStyle.Bold);

            this.lblPhongDaDatValue.Location =
                new System.Drawing.Point(470, 33);

            this.lblPhongDaDatValue.Text =
                "0";

            // ==========================================
            // PHÒNG ĐANG Ở
            // ==========================================

            this.lblPhongDangO.AutoSize = true;
            this.lblPhongDangO.Location =
                new System.Drawing.Point(540, 35);

            this.lblPhongDangO.Text =
                "Đang ở:";

            this.lblPhongDangOValue.AutoSize = true;
            this.lblPhongDangOValue.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    11F,
                    System.Drawing.FontStyle.Bold);

            this.lblPhongDangOValue.Location =
                new System.Drawing.Point(620, 33);

            this.lblPhongDangOValue.Text =
                "0";

            // ==========================================
            // TỔNG KHÁCH
            // ==========================================

            this.lblTongKhach.AutoSize = true;
            this.lblTongKhach.Location =
                new System.Drawing.Point(20, 75);

            this.lblTongKhach.Text =
                "Tổng khách hàng:";

            this.lblTongKhachValue.AutoSize = true;
            this.lblTongKhachValue.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    11F,
                    System.Drawing.FontStyle.Bold);

            this.lblTongKhachValue.Location =
                new System.Drawing.Point(145, 73);

            this.lblTongKhachValue.Text =
                "0";

            // ==========================================
            // TỔNG PHIẾU
            // ==========================================

            this.lblTongPhieuDat.AutoSize = true;
            this.lblTongPhieuDat.Location =
                new System.Drawing.Point(220, 75);

            this.lblTongPhieuDat.Text =
                "Tổng phiếu đặt:";

            this.lblTongPhieuDatValue.AutoSize = true;
            this.lblTongPhieuDatValue.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    11F,
                    System.Drawing.FontStyle.Bold);

            this.lblTongPhieuDatValue.Location =
                new System.Drawing.Point(340, 73);

            this.lblTongPhieuDatValue.Text =
                "0";

            // ==========================================
            // DỊCH VỤ
            // ==========================================

            this.lblTongDichVu.AutoSize = true;
            this.lblTongDichVu.Location =
                new System.Drawing.Point(400, 75);

            this.lblTongDichVu.Text =
                "Tiền dịch vụ:";

            this.lblTongDichVuValue.AutoSize = true;
            this.lblTongDichVuValue.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    10F,
                    System.Drawing.FontStyle.Bold);

            this.lblTongDichVuValue.Location =
                new System.Drawing.Point(500, 73);

            this.lblTongDichVuValue.Text =
                "0 đ";

            // ==========================================
            // ĐỀN BÙ
            // ==========================================

            this.lblTongDenBu.AutoSize = true;
            this.lblTongDenBu.Location =
                new System.Drawing.Point(20, 115);

            this.lblTongDenBu.Text =
                "Tiền đền bù:";

            this.lblTongDenBuValue.AutoSize = true;
            this.lblTongDenBuValue.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    10F,
                    System.Drawing.FontStyle.Bold);

            this.lblTongDenBuValue.Location =
                new System.Drawing.Point(145, 113);

            this.lblTongDenBuValue.Text =
                "0 đ";

            // ==========================================
            // DATAGRIDVIEW
            // ==========================================

            this.dgvThongKe.AllowUserToAddRows = false;
            this.dgvThongKe.AllowUserToDeleteRows = false;
            this.dgvThongKe.ColumnHeadersHeightSizeMode =
                System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            this.dgvThongKe.Location =
                new System.Drawing.Point(30, 255);

            this.dgvThongKe.Name =
                "dgvThongKe";

            this.dgvThongKe.ReadOnly = true;

            this.dgvThongKe.RowHeadersWidth = 30;

            this.dgvThongKe.SelectionMode =
                System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;

            this.dgvThongKe.Size =
                new System.Drawing.Size(840, 220);

            // ==========================================
            // NÚT LÀM MỚI
            // ==========================================

            this.btnLamMoi.Location =
                new System.Drawing.Point(570, 495);

            this.btnLamMoi.Name =
                "btnLamMoi";

            this.btnLamMoi.Size =
                new System.Drawing.Size(130, 40);

            this.btnLamMoi.Text =
                "Làm mới";

            this.btnLamMoi.UseVisualStyleBackColor = true;

            this.btnLamMoi.Click +=
                new System.EventHandler(
                    this.btnLamMoi_Click);

            // ==========================================
            // NÚT ĐÓNG
            // ==========================================

            this.btnDong.Location =
                new System.Drawing.Point(720, 495);

            this.btnDong.Name =
                "btnDong";

            this.btnDong.Size =
                new System.Drawing.Size(130, 40);

            this.btnDong.Text =
                "Đóng";

            this.btnDong.UseVisualStyleBackColor = true;

            this.btnDong.Click +=
                new System.EventHandler(
                    this.btnDong_Click);

            // ==========================================
            // FORM
            // ==========================================

            this.AutoScaleDimensions =
                new System.Drawing.SizeF(9F, 20F);

            this.AutoScaleMode =
                System.Windows.Forms.AutoScaleMode.Font;

            this.ClientSize =
                new System.Drawing.Size(900, 560);

            this.Controls.Add(
                this.btnDong);

            this.Controls.Add(
                this.btnLamMoi);

            this.Controls.Add(
                this.dgvThongKe);

            this.Controls.Add(
                this.grpTongQuan);

            this.Controls.Add(
                this.lblTieuDe);

            this.Font =
                new System.Drawing.Font(
                    "Segoe UI",
                    10F);

            this.FormBorderStyle =
                System.Windows.Forms.FormBorderStyle.FixedDialog;

            this.MaximizeBox = false;

            this.Name =
                "FrmThongKe";

            this.StartPosition =
                System.Windows.Forms.FormStartPosition.CenterScreen;

            this.Text =
                "Thống kê";

            this.grpTongQuan.ResumeLayout(false);
            this.grpTongQuan.PerformLayout();

            ((System.ComponentModel.ISupportInitialize)
                (this.dgvThongKe)).EndInit();

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTieuDe;

        private System.Windows.Forms.GroupBox grpTongQuan;

        private System.Windows.Forms.Label lblTongPhong;
        private System.Windows.Forms.Label lblTongPhongValue;

        private System.Windows.Forms.Label lblPhongTrong;
        private System.Windows.Forms.Label lblPhongTrongValue;

        private System.Windows.Forms.Label lblPhongDaDat;
        private System.Windows.Forms.Label lblPhongDaDatValue;

        private System.Windows.Forms.Label lblPhongDangO;
        private System.Windows.Forms.Label lblPhongDangOValue;

        private System.Windows.Forms.Label lblTongKhach;
        private System.Windows.Forms.Label lblTongKhachValue;

        private System.Windows.Forms.Label lblTongPhieuDat;
        private System.Windows.Forms.Label lblTongPhieuDatValue;

        private System.Windows.Forms.Label lblTongDichVu;
        private System.Windows.Forms.Label lblTongDichVuValue;

        private System.Windows.Forms.Label lblTongDenBu;
        private System.Windows.Forms.Label lblTongDenBuValue;

        private System.Windows.Forms.DataGridView dgvThongKe;

        private System.Windows.Forms.Button btnLamMoi;
        private System.Windows.Forms.Button btnDong;
    }
}