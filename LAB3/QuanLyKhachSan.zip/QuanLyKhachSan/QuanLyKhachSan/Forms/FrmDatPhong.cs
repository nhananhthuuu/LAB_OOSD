﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan
{
    public partial class FrmDatPhong : Form
    {
        public FrmDatPhong()
        {
            InitializeComponent();

            Load += FrmDatPhong_Load;

            tabDatPhong.SelectedIndexChanged += tabDatPhong_SelectedIndexChanged;

            btnLapPhieuDat.Click += btnLapPhieuDat_Click;

            dgvPhong.CellClick += dgvPhong_CellClick;
            dgvPhieuDat.CellClick += dgvPhieuDat_CellClick;
        }

        private void FrmDatPhong_Load(object sender, EventArgs e)
        {
            cboKenhDat.Items.Clear();
            cboKenhDat.Items.Add("Điện thoại");
            cboKenhDat.Items.Add("Website");
            cboKenhDat.Items.Add("Trực tiếp");
            cboKenhDat.SelectedIndex = 1;

            LoadPhong();
            LoadPhieuDat();
        }

        private void tabDatPhong_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabDatPhong.SelectedTab != null)
            {
                lblTieuDe.Text = tabDatPhong.SelectedTab.Text;
            }
        }

        private void LoadPhong()
        {
            try
            {
                string sql = @"
                    SELECT 
                        p.SoPhong AS [Phòng],
                        kv.TenKhuVuc AS [Khu],
                        p.SoNguoiToiDa AS [Sức chứa],
                        p.DonGiaNgay AS [Đơn giá],
                        p.TrangThai AS [Trạng thái]
                    FROM Phong p
                    INNER JOIN KhuVuc kv
                        ON p.MaKhuVuc = kv.MaKhuVuc
                    ORDER BY p.SoPhong";

                dgvPhong.DataSource = Db.Query(sql);

                dgvPhong.AutoSizeColumnsMode =
                    DataGridViewAutoSizeColumnsMode.Fill;

                dgvPhong.ReadOnly = true;
                dgvPhong.SelectionMode =
                    DataGridViewSelectionMode.FullRowSelect;
                dgvPhong.MultiSelect = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không tải được danh sách phòng.\n\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void LoadPhieuDat()
        {
            try
            {
                string sql = @"
                    SELECT
                        pd.SoPhieuDat AS [Số phiếu],
                        kh.HoTen AS [Khách],
                        pd.NgayNhan AS [Ngày nhận],
                        pd.NgayTraDuKien AS [Ngày trả dự kiến],
                        pd.TienCoc AS [Cọc],
                        pd.KenhDat AS [Kênh],
                        pd.TrangThai AS [Trạng thái]
                    FROM PhieuDatPhong pd
                    INNER JOIN KhachHang kh
                        ON pd.MaKhach = kh.MaKhach
                    ORDER BY pd.NgayLap DESC";

                dgvPhieuDat.DataSource = Db.Query(sql);

                dgvPhieuDat.AutoSizeColumnsMode =
                    DataGridViewAutoSizeColumnsMode.Fill;

                dgvPhieuDat.ReadOnly = true;
                dgvPhieuDat.SelectionMode =
                    DataGridViewSelectionMode.FullRowSelect;
                dgvPhieuDat.MultiSelect = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không tải được danh sách phiếu đặt.\n\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void dgvPhong_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow row = dgvPhong.Rows[e.RowIndex];

            if (row.Cells["Phòng"].Value != null)
            {
                txtPhongChon.Text =
                    row.Cells["Phòng"].Value.ToString();

                txtSoNguoi.Text = "1";

                if (row.Cells["Đơn giá"].Value != null)
                {
                    txtDonGia.Text =
                        row.Cells["Đơn giá"].Value.ToString();
                }
            }
        }

        private void dgvPhieuDat_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow row = dgvPhieuDat.Rows[e.RowIndex];

            if (row.Cells["Số phiếu"].Value != null)
            {
                txtSoPhieu.Text =
                    row.Cells["Số phiếu"].Value.ToString();
            }

            if (row.Cells["Khách"].Value != null)
            {
                txtKhach.Text =
                    row.Cells["Khách"].Value.ToString();
            }
        }

        private void btnLapPhieuDat_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSoPhieu.Text))
            {
                MessageBox.Show(
                    "Vui lòng nhập số phiếu đặt.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtMaKhach.Text))
            {
                MessageBox.Show(
                    "Vui lòng nhập mã khách.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtPhongChon.Text))
            {
                MessageBox.Show(
                    "Vui lòng chọn phòng.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string sqlCheck = @"
                    SELECT COUNT(*)
                    FROM KhachHang
                    WHERE MaKhach = @MaKhach";

                int tonTai = Convert.ToInt32(
                    Db.Scalar(
                        sqlCheck,
                        new SqlParameter("@MaKhach", txtMaKhach.Text.Trim())
                    )
                );

                if (tonTai == 0)
                {
                    MessageBox.Show(
                        "Mã khách hàng không tồn tại trong cơ sở dữ liệu.",
                        "Thông báo",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                string sql = @"
                    INSERT INTO PhieuDatPhong
                    (
                        SoPhieuDat,
                        MaKhach,
                        MaNVLeTan,
                        NgayLap,
                        NgayNhan,
                        NgayTraDuKien,
                        TienCoc,
                        KenhDat,
                        TrangThai
                    )
                    VALUES
                    (
                        @SoPhieuDat,
                        @MaKhach,
                        'NV01',
                        GETDATE(),
                        @NgayNhan,
                        @NgayTra,
                        @TienCoc,
                        @KenhDat,
                        N'Đã đặt'
                    )";

                Db.Execute(
                    sql,
                    new SqlParameter("@SoPhieuDat", txtSoPhieu.Text.Trim()),
                    new SqlParameter("@MaKhach", txtMaKhach.Text.Trim()),
                    new SqlParameter("@NgayNhan", dtNgayNhan.Value.Date),
                    new SqlParameter("@NgayTra", dtNgayTra.Value.Date),
                    new SqlParameter("@TienCoc",
                        decimal.TryParse(txtTienCoc.Text, out decimal coc)
                            ? coc
                            : 0),
                    new SqlParameter("@KenhDat",
                        cboKenhDat.Text)
                );

                string sqlCT = @"
                    INSERT INTO ChiTietDatPhong
                    (
                        SoPhieuDat,
                        SoPhong,
                        SoNguoi
                    )
                    VALUES
                    (
                        @SoPhieuDat,
                        @SoPhong,
                        @SoNguoi
                    )";

                Db.Execute(
                    sqlCT,
                    new SqlParameter("@SoPhieuDat", txtSoPhieu.Text.Trim()),
                    new SqlParameter("@SoPhong", txtPhongChon.Text.Trim()),
                    new SqlParameter("@SoNguoi",
                        int.TryParse(txtSoNguoi.Text, out int soNguoi)
                            ? soNguoi
                            : 1)
                );

                MessageBox.Show(
                    "Lập phiếu đặt phòng thành công!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LoadPhong();
                LoadPhieuDat();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể lập phiếu đặt phòng.\n\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}