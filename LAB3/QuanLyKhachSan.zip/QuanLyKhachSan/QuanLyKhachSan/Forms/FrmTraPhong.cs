﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan
{
    public partial class FrmTraPhong : Form
    {
        private decimal tongDenBu = 0;
        private string soHoaDonHienTai = "";

        public FrmTraPhong()
        {
            InitializeComponent();

            dtNgayTra.Value = DateTime.Now;

            if (cboHinhThuc.Items.Count > 0)
                cboHinhThuc.SelectedIndex = 0;

            txtTienPhong.Text = "0";
            txtTienDichVu.Text = "0";
            txtTienDenBu.Text = "0";
            txtTongTien.Text = "0";

            LoadPhieuDatPhong();
        }

        private void LoadPhieuDatPhong()
        {
            try
            {
                using (SqlConnection cn = QuanLyKhachSan.Data.Db.OpenConnection())
                {
                    string sql = @"
                        SELECT TOP 1
                            pd.SoPhieuDat
                        FROM PhieuDatPhong pd
                        INNER JOIN ChiTietDatPhong ct
                            ON pd.SoPhieuDat = ct.SoPhieuDat
                        WHERE pd.TrangThai IN (N'Đã đặt', N'Đang ở')
                        ORDER BY pd.NgayNhan ASC";

                    using (SqlCommand cmd = new SqlCommand(sql, cn))
                    {
                        object result = cmd.ExecuteScalar();

                        if (result != null)
                        {
                            txtSoPhieuDat.Text = result.ToString();
                            TimPhieuDat();
                        }
                        else
                        {
                            MessageBox.Show(
                                "Hiện chưa có phiếu đặt phòng để trả.",
                                "Thông báo",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể tải phiếu đặt phòng:\n\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            TimPhieuDat();
        }

        private void TimPhieuDat()
        {
            string soPhieuDat = txtSoPhieuDat.Text.Trim();

            if (string.IsNullOrWhiteSpace(soPhieuDat))
            {
                MessageBox.Show(
                    "Vui lòng nhập số phiếu đặt.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtSoPhieuDat.Focus();
                return;
            }

            try
            {
                using (SqlConnection cn = QuanLyKhachSan.Data.Db.OpenConnection())
                {
                    string sqlPhong = @"
                        SELECT TOP 1
                            ct.SoPhong,
                            p.DonGiaNgay,
                            pd.NgayNhan,
                            pd.NgayTraDuKien,
                            kh.HoTen,
                            DATEDIFF(DAY, pd.NgayNhan, @NgayTra) AS SoNgay
                        FROM PhieuDatPhong pd
                        INNER JOIN ChiTietDatPhong ct
                            ON pd.SoPhieuDat = ct.SoPhieuDat
                        INNER JOIN Phong p
                            ON ct.SoPhong = p.SoPhong
                        INNER JOIN KhachHang kh
                            ON pd.MaKhach = kh.MaKhach
                        WHERE pd.SoPhieuDat = @SoPhieuDat";

                    using (SqlCommand cmd = new SqlCommand(sqlPhong, cn))
                    {
                        cmd.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                        cmd.Parameters.AddWithValue("@NgayTra", dtNgayTra.Value.Date);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (!reader.Read())
                            {
                                MessageBox.Show(
                                    "Không tìm thấy phiếu đặt phòng.",
                                    "Thông báo",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                                return;
                            }

                            txtSoPhong.Text = reader["SoPhong"].ToString();

                            int soNgay = Convert.ToInt32(reader["SoNgay"]);
                            if (soNgay <= 0)
                                soNgay = 1;

                            decimal donGia = Convert.ToDecimal(reader["DonGiaNgay"]);

                            txtSoNgay.Text = soNgay.ToString();
                            txtTienPhong.Text = (soNgay * donGia).ToString("N0");
                        }
                    }

                    LoadDichVu(soPhieuDat);
                    TinhTongTien();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Không thể tải thông tin trả phòng:\n\n" + ex.Message,
                    "Lỗi",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void LoadDichVu(string soPhieuDat)
        {
            try
            {
                using (SqlConnection cn = QuanLyKhachSan.Data.Db.OpenConnection())
                {
                    string sql = @"
                        SELECT
                            ps.SoPhieuSDDV AS SoPhieu,
                            ps.SoPhong AS Phong,
                            ps.NgaySuDung AS Ngay,
                            dv.TenDV AS DichVu,
                            ct.SoLuong,
                            ct.DonGia,
                            ct.ThanhTien
                        FROM PhieuSuDungDV ps
                        INNER JOIN ChiTietPhieuSuDungDV ct
                            ON ps.SoPhieuSDDV = ct.SoPhieuSDDV
                        INNER JOIN DichVu dv
                            ON ct.MaDV = dv.MaDV
                        WHERE ps.SoPhieuDat = @SoPhieuDat
                        ORDER BY ps.NgaySuDung";

                    using (SqlDataAdapter da = new SqlDataAdapter(sql, cn))
                    {
                        da.SelectCommand.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);

                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        dgvDichVu.DataSource = dt;
                    }
                }

                DinhDangDichVu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể tải dịch vụ:\n\n" + ex.Message, "Lỗi");
            }
        }

        private void DinhDangDichVu()
        {
            if (dgvDichVu.Columns.Count == 0) return;

            if (dgvDichVu.Columns.Contains("SoPhieu"))
                dgvDichVu.Columns["SoPhieu"].HeaderText = "Số phiếu";
            if (dgvDichVu.Columns.Contains("Phong"))
                dgvDichVu.Columns["Phong"].HeaderText = "Phòng";
            if (dgvDichVu.Columns.Contains("Ngay"))
                dgvDichVu.Columns["Ngay"].HeaderText = "Ngày";
            if (dgvDichVu.Columns.Contains("DichVu"))
                dgvDichVu.Columns["DichVu"].HeaderText = "Dịch vụ";
            if (dgvDichVu.Columns.Contains("SoLuong"))
                dgvDichVu.Columns["SoLuong"].HeaderText = "Số lượng";
            if (dgvDichVu.Columns.Contains("DonGia"))
                dgvDichVu.Columns["DonGia"].HeaderText = "Đơn giá";
            if (dgvDichVu.Columns.Contains("ThanhTien"))
                dgvDichVu.Columns["ThanhTien"].HeaderText = "Thành tiền";

            if (dgvDichVu.Columns.Contains("Ngay"))
                dgvDichVu.Columns["Ngay"].DefaultCellStyle.Format = "dd/MM/yyyy";
            if (dgvDichVu.Columns.Contains("DonGia"))
                dgvDichVu.Columns["DonGia"].DefaultCellStyle.Format = "N0";
            if (dgvDichVu.Columns.Contains("ThanhTien"))
                dgvDichVu.Columns["ThanhTien"].DefaultCellStyle.Format = "N0";

            dgvDichVu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void TinhTongTien()
        {
            decimal tienPhong = 0;
            decimal tienDichVu = 0;

            decimal.TryParse(txtTienPhong.Text.Replace(",", ""), out tienPhong);

            foreach (DataGridViewRow row in dgvDichVu.Rows)
            {
                if (row.Cells["ThanhTien"].Value != null)
                {
                    decimal tien;
                    if (decimal.TryParse(row.Cells["ThanhTien"].Value.ToString(), out tien))
                    {
                        tienDichVu += tien;
                    }
                }
            }

            txtTienDichVu.Text = tienDichVu.ToString("N0");
            txtTienDenBu.Text = tongDenBu.ToString("N0");

            decimal tong = tienPhong + tienDichVu + tongDenBu;
            txtTongTien.Text = tong.ToString("N0");
        }

        private void btnThemDenBu_Click(object sender, EventArgs e)
        {
            decimal soTien;

            if (string.IsNullOrWhiteSpace(txtMaTienNghi.Text))
            {
                MessageBox.Show("Vui lòng nhập mã tiện nghi.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMaTienNghi.Focus();
                return;
            }

            if (!decimal.TryParse(txtSoTien.Text.Trim(), out soTien) || soTien < 0)
            {
                MessageBox.Show("Số tiền đền bù không hợp lệ.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSoTien.Focus();
                return;
            }

            tongDenBu += soTien;
            txtTienDenBu.Text = tongDenBu.ToString("N0");

            TinhTongTien();

            MessageBox.Show("Đã thêm khoản đền bù.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnLapHoaDon_Click(object sender, EventArgs e)
        {
            string soPhieuDat = txtSoPhieuDat.Text.Trim();

            if (string.IsNullOrWhiteSpace(soPhieuDat))
            {
                MessageBox.Show("Vui lòng nhập số phiếu đặt.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            decimal tienPhong = LaySoTien(txtTienPhong);
            decimal tienDichVu = LaySoTien(txtTienDichVu);

            try
            {
                using (SqlConnection cn = QuanLyKhachSan.Data.Db.OpenConnection())
                {
                    string soHoaDon = "HD" + DateTime.Now.ToString("yyyyMMddHHmmssfff");

                    string sql = @"
                        INSERT INTO HoaDon
                        (SoHoaDon, SoPhieuDat, NgayLap, MaNV, SoNgayTinhTien, TienPhong, TienDichVu, TrangThai)
                        VALUES
                        (@SoHoaDon, @SoPhieuDat, @NgayLap, @MaNV, @SoNgay, @TienPhong, @TienDichVu, N'Chưa thanh toán')";

                    using (SqlCommand cmd = new SqlCommand(sql, cn))
                    {
                        cmd.Parameters.AddWithValue("@SoHoaDon", soHoaDon);
                        cmd.Parameters.AddWithValue("@SoPhieuDat", soPhieuDat);
                        cmd.Parameters.AddWithValue("@NgayLap", DateTime.Now);
                        cmd.Parameters.AddWithValue("@MaNV", "NV03");
                        cmd.Parameters.AddWithValue("@SoNgay", LaySoNgay());
                        cmd.Parameters.AddWithValue("@TienPhong", tienPhong);
                        cmd.Parameters.AddWithValue("@TienDichVu", tienDichVu);

                        cmd.ExecuteNonQuery();
                    }

                    soHoaDonHienTai = soHoaDon;

                    MessageBox.Show(
                        "Lập hóa đơn thành công!\n\nSố hóa đơn: " + soHoaDon,
                        "Thông báo",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể lập hóa đơn:\n\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(soHoaDonHienTai))
            {
                MessageBox.Show("Bạn cần lập hóa đơn trước.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection cn = QuanLyKhachSan.Data.Db.OpenConnection())
                {
                    string maThanhToan = "TT" + DateTime.Now.ToString("yyyyMMddHHmmssfff");

                    string sqlThanhToan = @"
                        INSERT INTO ThanhToan
                        (MaThanhToan, SoHoaDon, NgayThanhToan, HinhThuc, SoTien)
                        VALUES
                        (@MaThanhToan, @SoHoaDon, @NgayThanhToan, @HinhThuc, @SoTien)";

                    using (SqlCommand cmd = new SqlCommand(sqlThanhToan, cn))
                    {
                        cmd.Parameters.AddWithValue("@MaThanhToan", maThanhToan);
                        cmd.Parameters.AddWithValue("@SoHoaDon", soHoaDonHienTai);
                        cmd.Parameters.AddWithValue("@NgayThanhToan", DateTime.Now);
                        cmd.Parameters.AddWithValue("@HinhThuc", cboHinhThuc.Text);
                        cmd.Parameters.AddWithValue("@SoTien", LaySoTien(txtTongTien));

                        cmd.ExecuteNonQuery();
                    }

                    string sqlUpdate = @"
                        UPDATE HoaDon
                        SET TrangThai = N'Đã thanh toán'
                        WHERE SoHoaDon = @SoHoaDon";

                    using (SqlCommand cmd = new SqlCommand(sqlUpdate, cn))
                    {
                        cmd.Parameters.AddWithValue("@SoHoaDon", soHoaDonHienTai);
                        cmd.ExecuteNonQuery();
                    }

                    string sqlPhong = @"
                        UPDATE Phong
                        SET TrangThai = N'Trống'
                        WHERE SoPhong = @SoPhong";

                    using (SqlCommand cmd = new SqlCommand(sqlPhong, cn))
                    {
                        cmd.Parameters.AddWithValue("@SoPhong", txtSoPhong.Text.Trim());
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Thanh toán thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không thể thanh toán:\n\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private decimal LaySoTien(TextBox textBox)
        {
            decimal value;
            decimal.TryParse(textBox.Text.Replace(",", ""), out value);
            return value;
        }

        private int LaySoNgay()
        {
            int soNgay;
            if (!int.TryParse(txtSoNgay.Text, out soNgay))
            {
                soNgay = 1;
            }

            if (soNgay <= 0)
                soNgay = 1;

            return soNgay;
        }

        private void btnMoi_Click(object sender, EventArgs e)
        {
            txtSoPhieuDat.Clear();
            txtSoPhong.Clear();
            txtSoNgay.Clear();

            txtTienPhong.Text = "0";
            txtTienDichVu.Text = "0";
            txtTienDenBu.Text = "0";
            txtTongTien.Text = "0";

            txtMaTienNghi.Clear();
            txtMucDo.Clear();
            txtSoTien.Clear();

            dgvDichVu.DataSource = null;

            tongDenBu = 0;
            soHoaDonHienTai = "";

            dtNgayTra.Value = DateTime.Now;

            if (cboHinhThuc.Items.Count > 0)
                cboHinhThuc.SelectedIndex = 0;

            LoadPhieuDatPhong();
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}