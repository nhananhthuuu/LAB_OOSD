﻿namespace QuanLyKhachSan
{
    partial class FrmDanhMuc
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabDanhMuc = new System.Windows.Forms.TabControl();
            this.tabKhuVuc = new System.Windows.Forms.TabPage();
            this.tabNhanVien = new System.Windows.Forms.TabPage();
            this.tabLoaiTienNghi = new System.Windows.Forms.TabPage();
            this.tabDichVu = new System.Windows.Forms.TabPage();
            this.tabQuyDinhDenBu = new System.Windows.Forms.TabPage();

            this.lblTieuDeDanhMuc = new System.Windows.Forms.Label();
            this.lblMa = new System.Windows.Forms.Label();
            this.lblTen = new System.Windows.Forms.Label();
            this.lblDonViVaiTro = new System.Windows.Forms.Label();

            this.txtMa = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.txtDonViVaiTro = new System.Windows.Forms.TextBox();

            this.btnThem = new System.Windows.Forms.Button();

            this.dgvDanhMuc = new System.Windows.Forms.DataGridView();

            this.colMa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLoaiVaiTro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonVi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonGiaMuc = new System.Windows.Forms.DataGridViewTextBoxColumn();

            this.tabDanhMuc.SuspendLayout();
            this.tabKhuVuc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMuc)).BeginInit();
            this.SuspendLayout();

            // 
            // tabDanhMuc
            // 
            this.tabDanhMuc.Controls.Add(this.tabKhuVuc);
            this.tabDanhMuc.Controls.Add(this.tabNhanVien);
            this.tabDanhMuc.Controls.Add(this.tabLoaiTienNghi);
            this.tabDanhMuc.Controls.Add(this.tabDichVu);
            this.tabDanhMuc.Controls.Add(this.tabQuyDinhDenBu);

            this.tabDanhMuc.Location = new System.Drawing.Point(20, 45);
            this.tabDanhMuc.Name = "tabDanhMuc";
            this.tabDanhMuc.SelectedIndex = 0;
            this.tabDanhMuc.Size = new System.Drawing.Size(950, 470);
            this.tabDanhMuc.TabIndex = 0;
            this.tabDanhMuc.SelectedIndexChanged += new System.EventHandler(this.tabDanhMuc_SelectedIndexChanged);

            // 
            // tabKhuVuc
            // 
            this.tabKhuVuc.Controls.Add(this.dgvDanhMuc);
            this.tabKhuVuc.Controls.Add(this.btnThem);
            this.tabKhuVuc.Controls.Add(this.txtDonViVaiTro);
            this.tabKhuVuc.Controls.Add(this.txtTen);
            this.tabKhuVuc.Controls.Add(this.txtMa);
            this.tabKhuVuc.Controls.Add(this.lblDonViVaiTro);
            this.tabKhuVuc.Controls.Add(this.lblTen);
            this.tabKhuVuc.Controls.Add(this.lblMa);
            this.tabKhuVuc.Controls.Add(this.lblTieuDeDanhMuc);

            this.tabKhuVuc.Location = new System.Drawing.Point(4, 29);
            this.tabKhuVuc.Name = "tabKhuVuc";
            this.tabKhuVuc.Padding = new System.Windows.Forms.Padding(3);
            this.tabKhuVuc.Size = new System.Drawing.Size(942, 437);
            this.tabKhuVuc.TabIndex = 0;
            this.tabKhuVuc.Text = "Khu vực";
            this.tabKhuVuc.UseVisualStyleBackColor = true;

            // 
            // tabNhanVien
            // 
            this.tabNhanVien.Location = new System.Drawing.Point(4, 29);
            this.tabNhanVien.Name = "tabNhanVien";
            this.tabNhanVien.Padding = new System.Windows.Forms.Padding(3);
            this.tabNhanVien.Size = new System.Drawing.Size(942, 437);
            this.tabNhanVien.TabIndex = 1;
            this.tabNhanVien.Text = "Nhân viên";
            this.tabNhanVien.UseVisualStyleBackColor = true;

            // 
            // tabLoaiTienNghi
            // 
            this.tabLoaiTienNghi.Location = new System.Drawing.Point(4, 29);
            this.tabLoaiTienNghi.Name = "tabLoaiTienNghi";
            this.tabLoaiTienNghi.Padding = new System.Windows.Forms.Padding(3);
            this.tabLoaiTienNghi.Size = new System.Drawing.Size(942, 437);
            this.tabLoaiTienNghi.TabIndex = 2;
            this.tabLoaiTienNghi.Text = "Loại tiện nghi";
            this.tabLoaiTienNghi.UseVisualStyleBackColor = true;

            // 
            // tabDichVu
            // 
            this.tabDichVu.Location = new System.Drawing.Point(4, 29);
            this.tabDichVu.Name = "tabDichVu";
            this.tabDichVu.Padding = new System.Windows.Forms.Padding(3);
            this.tabDichVu.Size = new System.Drawing.Size(942, 437);
            this.tabDichVu.TabIndex = 3;
            this.tabDichVu.Text = "Dịch vụ";
            this.tabDichVu.UseVisualStyleBackColor = true;

            // 
            // tabQuyDinhDenBu
            // 
            this.tabQuyDinhDenBu.Location = new System.Drawing.Point(4, 29);
            this.tabQuyDinhDenBu.Name = "tabQuyDinhDenBu";
            this.tabQuyDinhDenBu.Padding = new System.Windows.Forms.Padding(3);
            this.tabQuyDinhDenBu.Size = new System.Drawing.Size(942, 437);
            this.tabQuyDinhDenBu.TabIndex = 4;
            this.tabQuyDinhDenBu.Text = "Quy định đền bù";
            this.tabQuyDinhDenBu.UseVisualStyleBackColor = true;

            // 
            // lblTieuDeDanhMuc
            // 
            this.lblTieuDeDanhMuc.AutoSize = true;
            this.lblTieuDeDanhMuc.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTieuDeDanhMuc.Location = new System.Drawing.Point(20, 15);
            this.lblTieuDeDanhMuc.Name = "lblTieuDeDanhMuc";
            this.lblTieuDeDanhMuc.Size = new System.Drawing.Size(72, 25);
            this.lblTieuDeDanhMuc.TabIndex = 0;
            this.lblTieuDeDanhMuc.Text = "Khu vực";

            // 
            // lblMa
            // 
            this.lblMa.AutoSize = true;
            this.lblMa.Location = new System.Drawing.Point(25, 62);
            this.lblMa.Name = "lblMa";
            this.lblMa.Size = new System.Drawing.Size(37, 20);
            this.lblMa.TabIndex = 1;
            this.lblMa.Text = "Mã:";

            // 
            // txtMa
            // 
            this.txtMa.Location = new System.Drawing.Point(100, 58);
            this.txtMa.Name = "txtMa";
            this.txtMa.Size = new System.Drawing.Size(155, 27);
            this.txtMa.TabIndex = 2;
            this.txtMa.Text = "DV01";

            // 
            // lblTen
            // 
            this.lblTen.AutoSize = true;
            this.lblTen.Location = new System.Drawing.Point(285, 62);
            this.lblTen.Name = "lblTen";
            this.lblTen.Size = new System.Drawing.Size(39, 20);
            this.lblTen.TabIndex = 3;
            this.lblTen.Text = "Tên:";

            // 
            // txtTen
            // 
            this.txtTen.Location = new System.Drawing.Point(350, 58);
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(200, 27);
            this.txtTen.TabIndex = 4;
            this.txtTen.Text = "Ăn sáng";

            // 
            // lblDonViVaiTro
            // 
            this.lblDonViVaiTro.AutoSize = true;
            this.lblDonViVaiTro.Location = new System.Drawing.Point(570, 62);
            this.lblDonViVaiTro.Name = "lblDonViVaiTro";
            this.lblDonViVaiTro.Size = new System.Drawing.Size(111, 20);
            this.lblDonViVaiTro.TabIndex = 5;
            this.lblDonViVaiTro.Text = "Đơn vị / Vai trò:";

            // 
            // txtDonViVaiTro
            // 
            this.txtDonViVaiTro.Location = new System.Drawing.Point(690, 58);
            this.txtDonViVaiTro.Name = "txtDonViVaiTro";
            this.txtDonViVaiTro.Size = new System.Drawing.Size(145, 27);
            this.txtDonViVaiTro.TabIndex = 6;
            this.txtDonViVaiTro.Text = "Suất";

            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(845, 56);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(75, 32);
            this.btnThem.TabIndex = 7;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);

            //
            // dgvDanhMuc
            // 
            this.dgvDanhMuc.AllowUserToAddRows = false;
            this.dgvDanhMuc.AllowUserToDeleteRows = false;
            this.dgvDanhMuc.AllowUserToResizeRows = false;
            this.dgvDanhMuc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhMuc.BackgroundColor = System.Drawing.Color.White;
            this.dgvDanhMuc.ColumnHeadersHeight = 32;

            this.dgvDanhMuc.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colMa,
                this.colTen,
                this.colLoaiVaiTro,
                this.colDonVi,
                this.colDonGiaMuc
            });

            this.dgvDanhMuc.Location = new System.Drawing.Point(25, 115);
            this.dgvDanhMuc.MultiSelect = false;
            this.dgvDanhMuc.Name = "dgvDanhMuc";
            this.dgvDanhMuc.ReadOnly = true;
            this.dgvDanhMuc.RowHeadersVisible = false;
            this.dgvDanhMuc.RowTemplate.Height = 38;
            this.dgvDanhMuc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDanhMuc.Size = new System.Drawing.Size(895, 285);
            this.dgvDanhMuc.TabIndex = 8;

            // 
            // colMa
            // 
            this.colMa.HeaderText = "Mã";
            this.colMa.Name = "colMa";
            this.colMa.ReadOnly = true;

            // 
            // colTen
            // 
            this.colTen.HeaderText = "Tên";
            this.colTen.Name = "colTen";
            this.colTen.ReadOnly = true;

            // 
            // colLoaiVaiTro
            // 
            this.colLoaiVaiTro.HeaderText = "Loại / Vai trò";
            this.colLoaiVaiTro.Name = "colLoaiVaiTro";
            this.colLoaiVaiTro.ReadOnly = true;

            // 
            // colDonVi
            // 
            this.colDonVi.HeaderText = "Đơn vị";
            this.colDonVi.Name = "colDonVi";
            this.colDonVi.ReadOnly = true;

            // 
            // colDonGiaMuc
            // 
            this.colDonGiaMuc.HeaderText = "Đơn giá / Mức";
            this.colDonGiaMuc.Name = "colDonGiaMuc";
            this.colDonGiaMuc.ReadOnly = true;

            // 
            // FrmDanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(990, 550);
            this.Controls.Add(this.tabDanhMuc);
            this.Controls.Add(this.lblTieuDeDanhMuc);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmDanhMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh mục khách sạn";
            this.tabDanhMuc.ResumeLayout(false);
            this.tabKhuVuc.ResumeLayout(false);
            this.tabKhuVuc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMuc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TabControl tabDanhMuc;

        private System.Windows.Forms.TabPage tabKhuVuc;
        private System.Windows.Forms.TabPage tabNhanVien;
        private System.Windows.Forms.TabPage tabLoaiTienNghi;
        private System.Windows.Forms.TabPage tabDichVu;
        private System.Windows.Forms.TabPage tabQuyDinhDenBu;

        private System.Windows.Forms.Label lblTieuDeDanhMuc;
        private System.Windows.Forms.Label lblMa;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.Label lblDonViVaiTro;

        private System.Windows.Forms.TextBox txtMa;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.TextBox txtDonViVaiTro;

        private System.Windows.Forms.Button btnThem;

        private System.Windows.Forms.DataGridView dgvDanhMuc;

        private System.Windows.Forms.DataGridViewTextBoxColumn colMa;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTen;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLoaiVaiTro;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonVi;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonGiaMuc;
    }
}
