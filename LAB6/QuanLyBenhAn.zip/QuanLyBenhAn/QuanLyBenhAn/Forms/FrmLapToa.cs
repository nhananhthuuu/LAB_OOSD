﻿using QuanLyBenhAn.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyBenhAn
{
    // ToaThuoc.lapToa() + ChiTietToa.tinhThanhTien()
    public partial class FormLapToa : Form
    {
        private readonly DataTable dtCT = new DataTable();

        public FormLapToa()
        {
            InitializeComponent();
        }

        private void FormLapToa_Load(object sender, EventArgs e)
        {
            // Cấu trúc bảng chi tiết toa (lưu tạm trên lưới, bấm "Lưu toa" mới ghi xuống CSDL)
            dtCT.Columns.Add("MaThuoc", typeof(string));
            dtCT.Columns.Add("TenThuoc", typeof(string));
            dtCT.Columns.Add("SoLuong", typeof(int));
            dtCT.Columns.Add("DonGia", typeof(decimal));
            dtCT.Columns.Add("LieuDung", typeof(string));
            dtCT.Columns.Add("CachDung", typeof(string));
            dtCT.Columns.Add("ThanhTien", typeof(decimal));
            dgvChiTiet.DataSource = dtCT;

            dgvChiTiet.Columns["MaThuoc"].HeaderText = "Mã thuốc";
            dgvChiTiet.Columns["TenThuoc"].HeaderText = "Tên thuốc";
            dgvChiTiet.Columns["SoLuong"].HeaderText = "SL";
            dgvChiTiet.Columns["DonGia"].HeaderText = "Đơn giá";
            dgvChiTiet.Columns["LieuDung"].HeaderText = "Liều dùng";
            dgvChiTiet.Columns["CachDung"].HeaderText = "Cách dùng";
            dgvChiTiet.Columns["ThanhTien"].HeaderText = "Thành tiền";
            dgvChiTiet.Columns["DonGia"].DefaultCellStyle.Format = "N0";
            dgvChiTiet.Columns["ThanhTien"].DefaultCellStyle.Format = "N0";

            // Danh sách thuốc
            cboThuoc.DisplayMember = "TenThuoc";
            cboThuoc.ValueMember = "MaThuoc";
            cboThuoc.DataSource = Db.Query("SELECT MaThuoc, TenThuoc FROM Thuoc ORDER BY TenThuoc");

            LoadPhieuKham();
        }

        // Chỉ hiện các phiếu khám CHƯA có toa
        private void LoadPhieuKham()
        {
            DataTable dt = Db.Query(
                @"SELECT p.MaPK, p.MaPK + N' - ' + b.HoTen AS Ten
                  FROM PhieuKham p
                  JOIN HoSoBenhAn h ON h.MaHoSo = p.MaHoSo
                  JOIN BenhNhan b   ON b.MaBN = h.MaBN
                  WHERE NOT EXISTS (SELECT 1 FROM ToaThuoc t WHERE t.MaPK = p.MaPK)
                  ORDER BY p.NgayGioKham DESC");

            cboPhieuKham.DisplayMember = "Ten";
            cboPhieuKham.ValueMember = "MaPK";
            cboPhieuKham.DataSource = dt;

            if (dt.Rows.Count == 0)
                lblThongTin.Text = "Không có phiếu khám nào chưa lập toa.";
            else
                HienThongTinPhieu();
        }

        // Hiện triệu chứng cho bác sĩ tham khảo khi kê toa
        private void cboPhieuKham_SelectedIndexChanged(object sender, EventArgs e)
        {
            HienThongTinPhieu();
        }

        private void HienThongTinPhieu()
        {
            string pk = cboPhieuKham.SelectedValue as string;
            if (pk == null) return;

            DataTable dt = Db.Query(
                @"SELECT b.HoTen, p.LoaiKham, p.TrieuChung, p.NhietDo, p.HuyetAp
                  FROM PhieuKham p
                  JOIN HoSoBenhAn h ON h.MaHoSo = p.MaHoSo
                  JOIN BenhNhan b   ON b.MaBN = h.MaBN
                  WHERE p.MaPK = @pk",
                new SqlParameter("@pk", pk));
            if (dt.Rows.Count == 0) return;

            DataRow r = dt.Rows[0];
            lblThongTin.Text = string.Format(
                "Bệnh nhân: {0} ({1}) | Triệu chứng: {2} | Nhiệt độ: {3} | Huyết áp: {4}",
                r["HoTen"], r["LoaiKham"],
                r["TrieuChung"] == DBNull.Value ? "(chưa ghi)" : r["TrieuChung"],
                r["NhietDo"] == DBNull.Value ? "-" : r["NhietDo"],
                r["HuyetAp"] == DBNull.Value ? "-" : r["HuyetAp"]);
        }

        private void CapNhatTamTinh()
        {
            decimal tong = 0;
            foreach (DataRow r in dtCT.Rows) tong += (decimal)r["ThanhTien"];
            lblTamTinh.Text = "Tiền thuốc: " + tong.ToString("N0") + " đ";
        }

        private void btnThemThuoc_Click(object sender, EventArgs e)
        {
            string maThuoc = cboThuoc.SelectedValue as string;
            if (maThuoc == null) { MessageBox.Show("Chọn thuốc trước."); return; }

            int soLuong;
            if (!int.TryParse(txtSoLuong.Text.Trim(), out soLuong) || soLuong <= 0)
            {
                MessageBox.Show("Số lượng phải là số nguyên dương.");
                txtSoLuong.Focus();
                return;
            }

            // Không kê trùng 1 thuốc 2 lần trong cùng toa
            foreach (DataRow r in dtCT.Rows)
            {
                if ((string)r["MaThuoc"] == maThuoc)
                {
                    MessageBox.Show("Thuốc này đã có trong toa. Hãy xóa dòng cũ nếu muốn sửa số lượng.");
                    return;
                }
            }

            decimal donGia = Convert.ToDecimal(Db.Scalar(
                "SELECT DonGia FROM Thuoc WHERE MaThuoc = @m",
                new SqlParameter("@m", maThuoc)));

            dtCT.Rows.Add(maThuoc, cboThuoc.Text, soLuong, donGia,
                          txtLieuDung.Text.Trim(), txtCachDung.Text.Trim(), soLuong * donGia);

            txtSoLuong.Clear(); txtLieuDung.Clear(); txtCachDung.Clear();
            cboThuoc.Focus();
            CapNhatTamTinh();
        }

        private void btnXoaThuoc_Click(object sender, EventArgs e)
        {
            if (dgvChiTiet.CurrentRow == null) return;
            dtCT.Rows.RemoveAt(dgvChiTiet.CurrentRow.Index);
            CapNhatTamTinh();
        }

        // Lưu ToaThuoc + ChiTietToa trong 1 transaction
        private void btnLuuToa_Click(object sender, EventArgs e)
        {
            string pk = cboPhieuKham.SelectedValue as string;
            if (pk == null) { MessageBox.Show("Chưa chọn phiếu khám."); return; }
            if (dtCT.Rows.Count == 0) { MessageBox.Show("Toa thuốc phải có ít nhất 1 thuốc."); return; }

            using (SqlConnection cn = Db.OpenConnection())
            using (SqlTransaction tran = cn.BeginTransaction())
            {
                try
                {
                    string maToa = Db.NewId("TOA");

                    using (SqlCommand c1 = new SqlCommand(
                        "INSERT INTO ToaThuoc(MaToa, MaPK, GhiChu) VALUES(@toa, @pk, @gc)", cn, tran))
                    {
                        c1.Parameters.AddWithValue("@toa", maToa);
                        c1.Parameters.AddWithValue("@pk", pk);
                        c1.Parameters.AddWithValue("@gc", txtGhiChu.Text.Trim());
                        c1.ExecuteNonQuery();
                    }

                    int i = 1;
                    foreach (DataRow r in dtCT.Rows)
                    {
                        using (SqlCommand c2 = new SqlCommand(
                            @"INSERT INTO ChiTietToa(MaCT, MaToa, MaThuoc, SoLuong, LieuDung, CachDung)
                              VALUES(@ct, @toa, @thuoc, @sl, @ld, @cd)", cn, tran))
                        {
                            // MaCT <= 20 ký tự: "CT" + yyMMddHHmmss + số thứ tự 3 chữ số
                            c2.Parameters.AddWithValue("@ct",
                                "CT" + DateTime.Now.ToString("yyMMddHHmmss") + i.ToString("D3"));
                            c2.Parameters.AddWithValue("@toa", maToa);
                            c2.Parameters.AddWithValue("@thuoc", r["MaThuoc"]);
                            c2.Parameters.AddWithValue("@sl", r["SoLuong"]);
                            c2.Parameters.AddWithValue("@ld", r["LieuDung"]);
                            c2.Parameters.AddWithValue("@cd", r["CachDung"]);
                            c2.ExecuteNonQuery();
                        }
                        i++;
                    }

                    tran.Commit();
                    MessageBox.Show("Lập toa thuốc thành công!\nMã toa: " + maToa,
                                    "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    dtCT.Rows.Clear();
                    txtGhiChu.Clear();
                    CapNhatTamTinh();
                    LoadPhieuKham();      // phiếu vừa lập toa sẽ biến mất khỏi danh sách
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    MessageBox.Show("Không lưu được toa thuốc:\n" + ex.Message,
                                    "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
