﻿namespace QuanLyBenhAn
{
    partial class FormLapToa
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.grpPhieu = new System.Windows.Forms.GroupBox();
            this.lblPhieu = new System.Windows.Forms.Label();
            this.cboPhieuKham = new System.Windows.Forms.ComboBox();
            this.lblThongTin = new System.Windows.Forms.Label();
            this.grpThuoc = new System.Windows.Forms.GroupBox();
            this.lblThuoc = new System.Windows.Forms.Label();
            this.cboThuoc = new System.Windows.Forms.ComboBox();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.lblLieuDung = new System.Windows.Forms.Label();
            this.txtLieuDung = new System.Windows.Forms.TextBox();
            this.lblCachDung = new System.Windows.Forms.Label();
            this.txtCachDung = new System.Windows.Forms.TextBox();
            this.btnThemThuoc = new System.Windows.Forms.Button();
            this.btnXoaThuoc = new System.Windows.Forms.Button();
            this.dgvChiTiet = new System.Windows.Forms.DataGridView();
            this.lblGhiChu = new System.Windows.Forms.Label();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.lblTamTinh = new System.Windows.Forms.Label();
            this.btnLuuToa = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.grpPhieu.SuspendLayout();
            this.grpThuoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTiet)).BeginInit();
            this.SuspendLayout();

            // grpPhieu
            this.grpPhieu.Controls.Add(this.lblPhieu);
            this.grpPhieu.Controls.Add(this.cboPhieuKham);
            this.grpPhieu.Controls.Add(this.lblThongTin);
            this.grpPhieu.Location = new System.Drawing.Point(12, 12);
            this.grpPhieu.Size = new System.Drawing.Size(780, 95);
            this.grpPhieu.Text = "Thông tin phiếu khám";
            // lblPhieu
            this.lblPhieu.AutoSize = true;
            this.lblPhieu.Location = new System.Drawing.Point(15, 28);
            this.lblPhieu.Text = "Phiếu khám:";
            // cboPhieuKham
            this.cboPhieuKham.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhieuKham.Location = new System.Drawing.Point(100, 24);
            this.cboPhieuKham.Size = new System.Drawing.Size(400, 24);
            this.cboPhieuKham.SelectedIndexChanged += new System.EventHandler(this.cboPhieuKham_SelectedIndexChanged);
            // lblThongTin
            this.lblThongTin.Location = new System.Drawing.Point(15, 56);
            this.lblThongTin.Size = new System.Drawing.Size(750, 34);
            this.lblThongTin.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblThongTin.Text = "";

            // grpThuoc
            this.grpThuoc.Controls.Add(this.lblThuoc);
            this.grpThuoc.Controls.Add(this.cboThuoc);
            this.grpThuoc.Controls.Add(this.lblSoLuong);
            this.grpThuoc.Controls.Add(this.txtSoLuong);
            this.grpThuoc.Controls.Add(this.lblLieuDung);
            this.grpThuoc.Controls.Add(this.txtLieuDung);
            this.grpThuoc.Controls.Add(this.lblCachDung);
            this.grpThuoc.Controls.Add(this.txtCachDung);
            this.grpThuoc.Controls.Add(this.btnThemThuoc);
            this.grpThuoc.Controls.Add(this.btnXoaThuoc);
            this.grpThuoc.Location = new System.Drawing.Point(12, 115);
            this.grpThuoc.Size = new System.Drawing.Size(780, 125);
            this.grpThuoc.Text = "Chọn thuốc";
            // lblThuoc
            this.lblThuoc.AutoSize = true;
            this.lblThuoc.Location = new System.Drawing.Point(15, 30);
            this.lblThuoc.Text = "Thuốc:";
            // cboThuoc
            this.cboThuoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboThuoc.Location = new System.Drawing.Point(90, 26);
            this.cboThuoc.Size = new System.Drawing.Size(260, 24);
            // lblSoLuong
            this.lblSoLuong.AutoSize = true;
            this.lblSoLuong.Location = new System.Drawing.Point(370, 30);
            this.lblSoLuong.Text = "Số lượng:";
            // txtSoLuong
            this.txtSoLuong.Location = new System.Drawing.Point(440, 26);
            this.txtSoLuong.Size = new System.Drawing.Size(70, 22);
            // lblLieuDung
            this.lblLieuDung.AutoSize = true;
            this.lblLieuDung.Location = new System.Drawing.Point(15, 64);
            this.lblLieuDung.Text = "Liều dùng:";
            // txtLieuDung
            this.txtLieuDung.Location = new System.Drawing.Point(90, 60);
            this.txtLieuDung.Size = new System.Drawing.Size(260, 22);
            // lblCachDung
            this.lblCachDung.AutoSize = true;
            this.lblCachDung.Location = new System.Drawing.Point(370, 64);
            this.lblCachDung.Text = "Cách dùng:";
            // txtCachDung
            this.txtCachDung.Location = new System.Drawing.Point(440, 60);
            this.txtCachDung.Size = new System.Drawing.Size(320, 22);
            // btnThemThuoc
            this.btnThemThuoc.Location = new System.Drawing.Point(90, 90);
            this.btnThemThuoc.Size = new System.Drawing.Size(130, 28);
            this.btnThemThuoc.Text = "Thêm vào toa";
            this.btnThemThuoc.UseVisualStyleBackColor = true;
            this.btnThemThuoc.Click += new System.EventHandler(this.btnThemThuoc_Click);
            // btnXoaThuoc
            this.btnXoaThuoc.Location = new System.Drawing.Point(230, 90);
            this.btnXoaThuoc.Size = new System.Drawing.Size(130, 28);
            this.btnXoaThuoc.Text = "Xóa thuốc chọn";
            this.btnXoaThuoc.UseVisualStyleBackColor = true;
            this.btnXoaThuoc.Click += new System.EventHandler(this.btnXoaThuoc_Click);

            // dgvChiTiet
            this.dgvChiTiet.AllowUserToAddRows = false;
            this.dgvChiTiet.AllowUserToDeleteRows = false;
            this.dgvChiTiet.ReadOnly = true;
            this.dgvChiTiet.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChiTiet.MultiSelect = false;
            this.dgvChiTiet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChiTiet.RowHeadersVisible = false;
            this.dgvChiTiet.Location = new System.Drawing.Point(12, 248);
            this.dgvChiTiet.Size = new System.Drawing.Size(780, 210);

            // lblGhiChu
            this.lblGhiChu.AutoSize = true;
            this.lblGhiChu.Location = new System.Drawing.Point(12, 474);
            this.lblGhiChu.Text = "Ghi chú:";
            // txtGhiChu
            this.txtGhiChu.Location = new System.Drawing.Point(75, 470);
            this.txtGhiChu.Size = new System.Drawing.Size(717, 22);
            // lblTamTinh
            this.lblTamTinh.AutoSize = true;
            this.lblTamTinh.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblTamTinh.Location = new System.Drawing.Point(12, 510);
            this.lblTamTinh.Text = "Tiền thuốc: 0 đ";
            // btnLuuToa
            this.btnLuuToa.Location = new System.Drawing.Point(540, 505);
            this.btnLuuToa.Size = new System.Drawing.Size(150, 38);
            this.btnLuuToa.Text = "Lưu toa thuốc";
            this.btnLuuToa.UseVisualStyleBackColor = true;
            this.btnLuuToa.Click += new System.EventHandler(this.btnLuuToa_Click);
            // btnDong
            this.btnDong.Location = new System.Drawing.Point(700, 505);
            this.btnDong.Size = new System.Drawing.Size(92, 38);
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // FormLapToa
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 556);
            this.Controls.Add(this.grpPhieu);
            this.Controls.Add(this.grpThuoc);
            this.Controls.Add(this.dgvChiTiet);
            this.Controls.Add(this.lblGhiChu);
            this.Controls.Add(this.txtGhiChu);
            this.Controls.Add(this.lblTamTinh);
            this.Controls.Add(this.btnLuuToa);
            this.Controls.Add(this.btnDong);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FormLapToa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lập toa thuốc";
            this.Load += new System.EventHandler(this.FormLapToa_Load);
            this.grpPhieu.ResumeLayout(false);
            this.grpPhieu.PerformLayout();
            this.grpThuoc.ResumeLayout(false);
            this.grpThuoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChiTiet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.GroupBox grpPhieu;
        private System.Windows.Forms.Label lblPhieu;
        private System.Windows.Forms.ComboBox cboPhieuKham;
        private System.Windows.Forms.Label lblThongTin;
        private System.Windows.Forms.GroupBox grpThuoc;
        private System.Windows.Forms.Label lblThuoc;
        private System.Windows.Forms.ComboBox cboThuoc;
        private System.Windows.Forms.Label lblSoLuong;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.Label lblLieuDung;
        private System.Windows.Forms.TextBox txtLieuDung;
        private System.Windows.Forms.Label lblCachDung;
        private System.Windows.Forms.TextBox txtCachDung;
        private System.Windows.Forms.Button btnThemThuoc;
        private System.Windows.Forms.Button btnXoaThuoc;
        private System.Windows.Forms.DataGridView dgvChiTiet;
        private System.Windows.Forms.Label lblGhiChu;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Label lblTamTinh;
        private System.Windows.Forms.Button btnLuuToa;
        private System.Windows.Forms.Button btnDong;
    }
}