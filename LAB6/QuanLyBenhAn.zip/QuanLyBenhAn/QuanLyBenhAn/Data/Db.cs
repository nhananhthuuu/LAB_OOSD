﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyBenhAn.Data
{
    public static class Db
    {
        public const decimal LE_PHI_NAM = 500000;

        // Lấy chuỗi kết nối từ App.config
        public static string ConnectionString
        {
            get
            {
                var settings = ConfigurationManager.ConnectionStrings["QuanLyBenhAn"];
                if (settings == null)
                    throw new Exception("Không tìm thấy chuỗi kết nối 'QuanLyBenhAn' trong App.config!");
                return settings.ConnectionString;
            }
        }

        // Mở kết nối
        public static SqlConnection OpenConnection()
        {
            try
            {
                var cn = new SqlConnection(ConnectionString);
                cn.Open();
                return cn;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối CSDL SQL Server:\n" + ex.Message,
                                "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
        }

        // SELECT -> DataTable
        public static DataTable Query(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                if (parameters != null && parameters.Length > 0)
                    cmd.Parameters.AddRange(parameters);
                DataTable table = new DataTable();
                da.Fill(table);
                return table;
            }
        }

        // INSERT / UPDATE / DELETE
        public static int Execute(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                if (parameters != null && parameters.Length > 0)
                    cmd.Parameters.AddRange(parameters);
                return cmd.ExecuteNonQuery();
            }
        }

        // Trả về 1 giá trị (COUNT, SUM, MAX...)
        public static object Scalar(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                if (parameters != null && parameters.Length > 0)
                    cmd.Parameters.AddRange(parameters);
                return cmd.ExecuteScalar();
            }
        }

        // ===== THÊM MỚI so với bản cũ =====

        // Gọi stored procedure (sp_TimHoSo, sp_LichSuKham)
        public static DataTable Proc(string name, params SqlParameter[] parameters)
        {
            using (SqlConnection cn = OpenConnection())
            using (SqlCommand cmd = new SqlCommand(name, cn))
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (parameters != null && parameters.Length > 0)
                    cmd.Parameters.AddRange(parameters);
                DataTable table = new DataTable();
                da.Fill(table);
                return table;
            }
        }

        // Sinh mã tự động: NewId("PK") -> PK261016153045123
        public static string NewId(string prefix)
        {
            return prefix + DateTime.Now.ToString("yyMMddHHmmssfff");
        }

        // Bệnh nhân còn hồ sơ hợp lệ không? (kiemTraConHan)
        public static bool HoSoConHan(string maBN)
        {
            object kq = Scalar(
                "SELECT COUNT(*) FROM HoSoBenhAn WHERE MaBN=@bn AND NgayHetHan >= CAST(GETDATE() AS DATE)",
                new SqlParameter("@bn", maBN));
            return Convert.ToInt32(kq) > 0;
        }
    }
}
