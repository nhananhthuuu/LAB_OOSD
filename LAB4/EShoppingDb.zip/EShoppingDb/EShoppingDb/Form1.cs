﻿using System;
using System.Windows.Forms;

namespace EShoppingDb
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Đăng ký sự kiện lúc form vừa load lên
            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Gọi lệnh test kết nối từ file Database.cs tao vừa đưa mày hồi nãy
            Database db = new Database();
            db.TestConnection();
        }
    }
}