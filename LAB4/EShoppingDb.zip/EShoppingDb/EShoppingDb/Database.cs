﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EShoppingDb
{
    public class Database
    {
        // Nhớ sửa lại tên CSDL eSHOPPING cho đúng với tên mày đặt trong SQL Server
        private string connectionString = @"Data Source=.;Initial Catalog=EShoppingDB;Integrated Security=True";

        public SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        public void TestConnection()
        {
            try
            {
                using (SqlConnection conn = GetConnection())
                {
                    conn.Open();
                    MessageBox.Show("Kết nối cơ sở dữ liệu EShoppingDB thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kết nối dữ liệu thất bại!\n\n" + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}