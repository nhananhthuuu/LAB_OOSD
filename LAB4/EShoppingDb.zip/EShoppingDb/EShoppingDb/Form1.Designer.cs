﻿namespace EShoppingDb
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.btnNhomSanPham = new System.Windows.Forms.Button();
            this.btnSanPham = new System.Windows.Forms.Button();
            this.btnKhachHang = new System.Windows.Forms.Button();
            this.btnGioHang = new System.Windows.Forms.Button();
            this.btnDonHang = new System.Windows.Forms.Button();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnGiaoHang = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // lblTieuDe
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Arial", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.Location = new System.Drawing.Point(180, 40);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(480, 35);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "HỆ THỐNG QUẢN LÝ E-SHOPPING";

            // btnNhomSanPham
            this.btnNhomSanPham.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnNhomSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhomSanPham.Location = new System.Drawing.Point(180, 120);
            this.btnNhomSanPham.Name = "btnNhomSanPham";
            this.btnNhomSanPham.Size = new System.Drawing.Size(220, 50);
            this.btnNhomSanPham.TabIndex = 1;
            this.btnNhomSanPham.Text = "Quản lý nhóm sản phẩm";
            this.btnNhomSanPham.UseVisualStyleBackColor = false;

            // btnSanPham
            this.btnSanPham.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSanPham.Location = new System.Drawing.Point(440, 120);
            this.btnSanPham.Name = "btnSanPham";
            this.btnSanPham.Size = new System.Drawing.Size(220, 50);
            this.btnSanPham.TabIndex = 2;
            this.btnSanPham.Text = "Quản lý sản phẩm";
            this.btnSanPham.UseVisualStyleBackColor = false;

            // btnKhachHang
            this.btnKhachHang.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhachHang.Location = new System.Drawing.Point(180, 200);
            this.btnKhachHang.Name = "btnKhachHang";
            this.btnKhachHang.Size = new System.Drawing.Size(220, 50);
            this.btnKhachHang.TabIndex = 3;
            this.btnKhachHang.Text = "Quản lý khách hàng";
            this.btnKhachHang.UseVisualStyleBackColor = false;

            // btnGioHang
            this.btnGioHang.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnGioHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGioHang.Location = new System.Drawing.Point(440, 200);
            this.btnGioHang.Name = "btnGioHang";
            this.btnGioHang.Size = new System.Drawing.Size(220, 50);
            this.btnGioHang.TabIndex = 4;
            this.btnGioHang.Text = "Quản lý giỏ hàng";
            this.btnGioHang.UseVisualStyleBackColor = false;

            // btnDonHang
            this.btnDonHang.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnDonHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDonHang.Location = new System.Drawing.Point(180, 280);
            this.btnDonHang.Name = "btnDonHang";
            this.btnDonHang.Size = new System.Drawing.Size(220, 50);
            this.btnDonHang.TabIndex = 5;
            this.btnDonHang.Text = "Quản lý đơn hàng";
            this.btnDonHang.UseVisualStyleBackColor = false;

            // btnThanhToan
            this.btnThanhToan.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnThanhToan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThanhToan.Location = new System.Drawing.Point(440, 280);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(220, 50);
            this.btnThanhToan.TabIndex = 6;
            this.btnThanhToan.Text = "Quản lý thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = false;

            // btnGiaoHang
            this.btnGiaoHang.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnGiaoHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGiaoHang.Location = new System.Drawing.Point(180, 360);
            this.btnGiaoHang.Name = "btnGiaoHang";
            this.btnGiaoHang.Size = new System.Drawing.Size(220, 50);
            this.btnGiaoHang.TabIndex = 7;
            this.btnGiaoHang.Text = "Quản lý loại giao hàng";
            this.btnGiaoHang.UseVisualStyleBackColor = false;

            // btnThoat
            this.btnThoat.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Location = new System.Drawing.Point(440, 360);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(220, 50);
            this.btnThoat.TabIndex = 8;
            this.btnThoat.Text = "Thoát chương trình";
            this.btnThoat.UseVisualStyleBackColor = false;

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(840, 480);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnGiaoHang);
            this.Controls.Add(this.btnThanhToan);
            this.Controls.Add(this.btnDonHang);
            this.Controls.Add(this.btnGioHang);
            this.Controls.Add(this.btnKhachHang);
            this.Controls.Add(this.btnSanPham);
            this.Controls.Add(this.btnNhomSanPham);
            this.Controls.Add(this.lblTieuDe);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Hệ thống quản lý e-SHOPPING";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Button btnNhomSanPham;
        private System.Windows.Forms.Button btnSanPham;
        private System.Windows.Forms.Button btnKhachHang;
        private System.Windows.Forms.Button btnGioHang;
        private System.Windows.Forms.Button btnDonHang;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnGiaoHang;
        private System.Windows.Forms.Button btnThoat;
    }
}