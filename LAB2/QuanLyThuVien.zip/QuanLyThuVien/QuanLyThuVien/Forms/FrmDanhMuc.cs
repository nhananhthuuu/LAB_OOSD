﻿using QuanLyThuVien.Data;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QuanLyThuVien.Forms
{
    public partial class FrmDanhMuc : Form
    {
        public FrmDanhMuc()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                // Load dữ liệu từ bảng TheLoai trong SQL
                DataTable dt = Db.Query("SELECT * FROM TheLoai");
                dataGridView1.DataSource = dt; // Khớp với tên mặc định dataGridView1
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e) // Nút Thêm (mặc định button1)
        {
            try
            {
                string sql = "INSERT INTO TheLoai (MaTheLoai, TenTheLoai) VALUES (@Ma, @Ten)";
                Db.Execute(sql, new SqlParameter("@Ma", textBox1.Text.Trim()), new SqlParameter("@Ten", textBox2.Text.Trim()));
                LoadData();
                MessageBox.Show("Thêm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi thêm: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e) // Nút Sửa (tùy theo vị trí nút trên form của Lệ)
        {
            try
            {
                string sql = "UPDATE TheLoai SET TenTheLoai = @Ten WHERE MaTheLoai = @Ma";
                Db.Execute(sql, new SqlParameter("@Ma", textBox1.Text.Trim()), new SqlParameter("@Ten", textBox2.Text.Trim()));
                LoadData();
                MessageBox.Show("Sửa thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi sửa: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e) // Nút Xóa (tùy theo vị trí nút trên form của Lệ)
        {
            try
            {
                if (MessageBox.Show("Bạn có chắc chắn muốn xóa?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string sql = "DELETE FROM TheLoai WHERE MaTheLoai = @Ma";
                    Db.Execute(sql, new SqlParameter("@Ma", textBox1.Text.Trim()));
                    LoadData();
                    MessageBox.Show("Xóa thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi xóa: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e) // Nút Làm mới (mặc định button4)
        {
            textBox1.Clear();
            textBox2.Clear();
            LoadData();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["MaTheLoai"].Value.ToString();
                textBox2.Text = row.Cells["TenTheLoai"].Value.ToString();
            }
        }
    }
}