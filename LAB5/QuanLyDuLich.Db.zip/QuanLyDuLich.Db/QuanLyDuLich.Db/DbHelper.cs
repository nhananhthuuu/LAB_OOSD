﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyDuLich
{
    public static class DbHelper
    {
        // Server: localhost  |  CSDL: QuanLyDuLich  |  Đăng nhập bằng tài khoản Windows
        public static readonly string ConnStr =
            @"Data Source=localhost;Initial Catalog=QuanLyDuLich;Integrated Security=True";

        // Tạo tham số SQL (null thì đổi thành NULL của SQL)
        public static SqlParameter P(string name, object value)
        {
            return new SqlParameter(name, value ?? DBNull.Value);
        }

        // Chạy SELECT, trả về bảng dữ liệu
        public static DataTable GetTable(string sql, params SqlParameter[] ps)
        {
            using (var cn = new SqlConnection(ConnStr))
            using (var cmd = new SqlCommand(sql, cn))
            using (var da = new SqlDataAdapter(cmd))
            {
                if (ps != null) cmd.Parameters.AddRange(ps);
                var dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        // Chạy INSERT / UPDATE / DELETE
        public static int Execute(string sql, params SqlParameter[] ps)
        {
            using (var cn = new SqlConnection(ConnStr))
            using (var cmd = new SqlCommand(sql, cn))
            {
                if (ps != null) cmd.Parameters.AddRange(ps);
                cn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        // Chạy câu lệnh trả về 1 giá trị
        public static object Scalar(string sql, params SqlParameter[] ps)
        {
            using (var cn = new SqlConnection(ConnStr))
            using (var cmd = new SqlCommand(sql, cn))
            {
                if (ps != null) cmd.Parameters.AddRange(ps);
                cn.Open();
                return cmd.ExecuteScalar();
            }
        }

        // Đổi lỗi SQL thành câu dễ hiểu
        public static string Loi(Exception ex)
        {
            var sql = ex as SqlException;
            if (sql != null)
            {
                switch (sql.Number)
                {
                    case 2627:
                    case 2601:
                        return "Dữ liệu bị TRÙNG (mã hoặc tên đã tồn tại).";
                    case 547:
                        return "Không thực hiện được: giá trị không hợp lệ, hoặc dữ liệu này đang được " +
                               "dùng ở nơi khác (ví dụ tour đã có chuyến đi / phiếu đăng ký).";
                }
            }
            return ex.Message;
        }
    }
}