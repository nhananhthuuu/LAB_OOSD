﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyDuLich
{
    public partial class Form1 : Form
    {
        private TextBox txtMa, txtTen, txtGia, txtTim;
        private NumericUpDown nudNgay, nudDem;
        private DataGridView dgv;

        public Form1()
        {
            InitializeComponent();
            BuildUI();
            Load += (s, e) => LamMoi();
        }

        // =====================================================
        //  VẼ GIAO DIỆN
        // =====================================================
        private void NhanLabel(Control cha, string text, int x, int y)
        {
            cha.Controls.Add(new Label { Text = text, Left = x, Top = y, AutoSize = true });
        }

        private Button TaoNut(string text, int x, Color nen, EventHandler click)
        {
            var b = new Button { Text = text, Left = x, Top = 232, Width = 90, Height = 36 };
            if (nen != Color.Empty)
            {
                b.BackColor = nen;
                b.ForeColor = Color.White;
                b.FlatStyle = FlatStyle.Flat;
                b.FlatAppearance.BorderSize = 0;
                b.UseVisualStyleBackColor = false;
            }
            b.Click += click;
            Controls.Add(b);
            return b;
        }

        private void BuildUI()
        {
            AutoScaleMode = AutoScaleMode.None;
            Font = new Font("Segoe UI", 10F);
            Text = "Quản lý Tour";
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            ClientSize = new Size(760, 570);

            // Tiêu đề
            Controls.Add(new Label
            {
                Text = "QUẢN LÝ TOUR DU LỊCH",
                Font = new Font("Segoe UI", 20F, FontStyle.Bold),
                ForeColor = Color.Navy,
                AutoSize = true,
                Left = 15,
                Top = 10
            });

            // Khung thông tin tour
            var grp = new GroupBox { Text = "Thông tin tour", Left = 12, Top = 62, Width = 736, Height = 155 };
            Controls.Add(grp);

            NhanLabel(grp, "Mã tour:", 30, 35);
            txtMa = new TextBox { Left = 115, Top = 31, Width = 200, MaxLength = 10 };
            grp.Controls.Add(txtMa);

            NhanLabel(grp, "Tên tour:", 370, 35);
            txtTen = new TextBox { Left = 445, Top = 31, Width = 270, MaxLength = 150 };
            grp.Controls.Add(txtTen);

            NhanLabel(grp, "Số ngày:", 30, 75);
            nudNgay = new NumericUpDown { Left = 115, Top = 71, Width = 75, Minimum = 1, Maximum = 60, Value = 1 };
            grp.Controls.Add(nudNgay);

            NhanLabel(grp, "Số đêm:", 370, 75);
            nudDem = new NumericUpDown { Left = 445, Top = 71, Width = 75, Minimum = 0, Maximum = 60, Value = 0 };
            grp.Controls.Add(nudDem);

            NhanLabel(grp, "Đơn giá:", 30, 115);
            txtGia = new TextBox { Left = 115, Top = 111, Width = 200, TextAlign = HorizontalAlignment.Right };
            grp.Controls.Add(txtGia);
            NhanLabel(grp, "VNĐ / khách", 325, 115);

            // Hàng nút
            TaoNut("Thêm", 12, Color.SeaGreen, BtnThem_Click);
            TaoNut("Sửa", 112, Color.SteelBlue, BtnSua_Click);
            TaoNut("Xóa", 212, Color.IndianRed, BtnXoa_Click);
            TaoNut("Làm mới", 312, Color.Empty, (s, e) => LamMoi());

            txtTim = new TextBox { Left = 430, Top = 238, Width = 200 };
            txtTim.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; BtnTim_Click(null, null); }
            };
            Controls.Add(txtTim);

            var btnTim = new Button { Text = "Tìm kiếm", Left = 645, Top = 232, Width = 103, Height = 36 };
            btnTim.Click += BtnTim_Click;
            Controls.Add(btnTim);

            // Bảng dữ liệu
            dgv = new DataGridView
            {
                Left = 12,
                Top = 285,
                Width = 736,
                Height = 272,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.DarkGray,
                BorderStyle = BorderStyle.FixedSingle
            };
            dgv.CellClick += Dgv_CellClick;
            Controls.Add(dgv);
        }

        // =====================================================
        //  TẢI DỮ LIỆU
        // =====================================================
        private void LoadData(string tuKhoa)
        {
            string sql = "SELECT MaTour, TenTour, SoNgay, SoDem, DonGia FROM Tour";
            DataTable dt;
            if (string.IsNullOrWhiteSpace(tuKhoa))
            {
                dt = DbHelper.GetTable(sql + " ORDER BY MaTour");
            }
            else
            {
                dt = DbHelper.GetTable(sql + " WHERE MaTour LIKE @kw OR TenTour LIKE @kw ORDER BY MaTour",
                    DbHelper.P("@kw", "%" + tuKhoa.Trim() + "%"));
            }
            dgv.DataSource = dt;

            dgv.Columns["MaTour"].HeaderText = "Mã tour";
            dgv.Columns["TenTour"].HeaderText = "Tên tour";
            dgv.Columns["SoNgay"].HeaderText = "Số ngày";
            dgv.Columns["SoDem"].HeaderText = "Số đêm";
            dgv.Columns["DonGia"].HeaderText = "Đơn giá (VNĐ)";
            dgv.Columns["DonGia"].DefaultCellStyle.Format = "N0";
            dgv.Columns["MaTour"].FillWeight = 60;
            dgv.Columns["TenTour"].FillWeight = 180;
            dgv.Columns["SoNgay"].FillWeight = 70;
            dgv.Columns["SoDem"].FillWeight = 70;
            dgv.Columns["DonGia"].FillWeight = 100;
        }

        // Mã tour kế tiếp: T01, T02, T03...
        private string MaTourMoi()
        {
            object o = DbHelper.Scalar(
                "SELECT ISNULL(MAX(TRY_CAST(SUBSTRING(MaTour,2,10) AS INT)),0)+1 FROM Tour WHERE MaTour LIKE 'T[0-9]%'");
            return "T" + Convert.ToInt32(o).ToString("D2");
        }

        private void LamMoi()
        {
            try
            {
                txtTim.Clear();
                txtTen.Clear();
                txtGia.Clear();
                nudNgay.Value = 1;
                nudDem.Value = 0;
                txtMa.ReadOnly = false;
                txtMa.BackColor = SystemColors.Window;
                LoadData(null);
                txtMa.Text = MaTourMoi();     // tự gợi ý mã mới
                txtTen.Focus();
            }
            catch (Exception ex) { Loi(ex); }
        }

        // Bấm vào 1 dòng thì hiện thông tin lên khung phía trên
        private void Dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var r = dgv.Rows[e.RowIndex];
            txtMa.Text = Convert.ToString(r.Cells["MaTour"].Value);
            txtTen.Text = Convert.ToString(r.Cells["TenTour"].Value);
            nudNgay.Value = Convert.ToDecimal(r.Cells["SoNgay"].Value);
            nudDem.Value = Convert.ToDecimal(r.Cells["SoDem"].Value);
            txtGia.Text = Convert.ToDecimal(r.Cells["DonGia"].Value).ToString("0");
            txtMa.ReadOnly = true;                    // không cho đổi khóa chính
            txtMa.BackColor = SystemColors.Control;   // tô xám như trong hình
        }

        // =====================================================
        //  KIỂM TRA DỮ LIỆU NHẬP
        // =====================================================
        private bool DocForm(out string ma, out string ten, out int ngay, out int dem, out decimal gia)
        {
            ma = txtMa.Text.Trim();
            ten = txtTen.Text.Trim();
            ngay = (int)nudNgay.Value;
            dem = (int)nudDem.Value;
            gia = 0;

            if (ma == "" || ten == "")
            {
                Canh("Vui lòng nhập Mã tour và Tên tour.");
                return false;
            }
            if (dem < ngay - 1 || dem > ngay)
            {
                Canh("Số đêm phải bằng số ngày hoặc ít hơn số ngày 1\n(ví dụ: 3 ngày 2 đêm, hoặc 3 ngày 3 đêm).");
                return false;
            }
            string s = txtGia.Text.Replace(".", "").Replace(",", "").Replace(" ", "");
            if (!decimal.TryParse(s, out gia) || gia <= 0)
            {
                Canh("Đơn giá phải là số lớn hơn 0 (ví dụ: 3200000).");
                return false;
            }
            return true;
        }

        // =====================================================
        //  CÁC NÚT
        // =====================================================
        private void BtnThem_Click(object sender, EventArgs e)
        {
            string ma, ten; int ngay, dem; decimal gia;
            if (!DocForm(out ma, out ten, out ngay, out dem, out gia)) return;
            try
            {
                DbHelper.Execute(
                    "INSERT INTO Tour(MaTour,TenTour,SoNgay,SoDem,DonGia) VALUES(@ma,@ten,@ng,@dem,@gia)",
                    DbHelper.P("@ma", ma), DbHelper.P("@ten", ten),
                    DbHelper.P("@ng", ngay), DbHelper.P("@dem", dem), DbHelper.P("@gia", gia));
                Info("Thêm tour thành công.");
                LamMoi();
            }
            catch (Exception ex) { Loi(ex); }
        }

        private void BtnSua_Click(object sender, EventArgs e)
        {
            if (!txtMa.ReadOnly) { Canh("Hãy bấm chọn 1 tour trong bảng trước khi sửa."); return; }
            string ma, ten; int ngay, dem; decimal gia;
            if (!DocForm(out ma, out ten, out ngay, out dem, out gia)) return;
            try
            {
                DbHelper.Execute(
                    "UPDATE Tour SET TenTour=@ten, SoNgay=@ng, SoDem=@dem, DonGia=@gia WHERE MaTour=@ma",
                    DbHelper.P("@ma", ma), DbHelper.P("@ten", ten),
                    DbHelper.P("@ng", ngay), DbHelper.P("@dem", dem), DbHelper.P("@gia", gia));
                Info("Cập nhật tour thành công.");
                LamMoi();
            }
            catch (Exception ex) { Loi(ex); }
        }

        private void BtnXoa_Click(object sender, EventArgs e)
        {
            if (!txtMa.ReadOnly) { Canh("Hãy bấm chọn 1 tour trong bảng trước khi xóa."); return; }
            if (MessageBox.Show("Bạn có chắc muốn xóa tour \"" + txtTen.Text + "\"?", "Xác nhận xóa",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try
            {
                DbHelper.Execute("DELETE FROM Tour WHERE MaTour=@ma", DbHelper.P("@ma", txtMa.Text.Trim()));
                Info("Đã xóa tour.");
                LamMoi();
            }
            catch (Exception ex) { Loi(ex); }
        }

        private void BtnTim_Click(object sender, EventArgs e)
        {
            try
            {
                string kw = txtTim.Text;
                LoadData(kw);
                if (!string.IsNullOrWhiteSpace(kw) && dgv.Rows.Count == 0)
                    Info("Không tìm thấy tour nào khớp với \"" + kw.Trim() + "\".");
            }
            catch (Exception ex) { Loi(ex); }
        }

        // =====================================================
        //  HỘP THOẠI
        // =====================================================
        private void Info(string msg) { MessageBox.Show(msg, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        private void Canh(string msg) { MessageBox.Show(msg, "Chú ý", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        private void Loi(Exception ex) { MessageBox.Show(DbHelper.Loi(ex), "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }
}